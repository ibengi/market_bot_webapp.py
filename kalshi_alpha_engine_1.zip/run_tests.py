#!/usr/bin/env python3
"""
run_tests.py — execute la decouverte unittest et ECRIT test_report.json a
partir des resultats REELS (jamais fabrique a la main).

Usage :
    python run_tests.py            # discover + rapport
Code retour : 0 si tout passe (les skips sont autorises), 1 sinon.
"""
import io
import json
import sys
import unittest
from datetime import datetime, timezone


def main() -> int:
    loader = unittest.TestLoader()
    suite = loader.discover(".", pattern="test_*.py")
    stream = io.StringIO()
    runner = unittest.TextTestRunner(stream=stream, verbosity=2)
    result = runner.run(suite)
    output = stream.getvalue()
    sys.stderr.write(output)

    report = {
        "generated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "command": "python run_tests.py (unittest discover)",
        "ran": result.testsRun,
        "passed": result.testsRun - len(result.failures)
                  - len(result.errors) - len(result.skipped),
        "failed": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "skipped_detail": [f"{t.id()}: {r}" for t, r in result.skipped],
        "failed_detail": [t.id() for t, _ in result.failures],
        "error_detail": [t.id() for t, _ in result.errors],
        "success": result.wasSuccessful(),
        "coverage": ("non mesuree par ce runner; executer "
                     "'pip install pytest pytest-cov && pytest --cov' "
                     "pour un pourcentage"),
    }
    with open("test_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1, ensure_ascii=False)
    print(json.dumps({k: report[k] for k in
                      ("ran", "passed", "failed", "errors", "skipped",
                       "success")}))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
