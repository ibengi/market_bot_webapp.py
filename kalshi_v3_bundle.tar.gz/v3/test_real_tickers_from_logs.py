"""
test_real_tickers_from_logs.py — les tickers REELS des logs Railway fournis,
passes dans la VRAIE chaine du depot : build_snapshot (normalisation) ->
classify_market_type (taxonomie) -> StrategyRouter + BtcModelStrategy
(vrai registre, vraie strategie ; seuls les fournisseurs de contexte/modele
sont injectes car btc_context.py et btc_probability_model.py n'ont pas ete
fournis — supports()/le routage n'utilisent PAS ces fournisseurs).

Verdicts attendus (table de support, section 6 du cahier des charges) :
    KXWNBAGAME-26JUL20NYDAL-DAL      sports_moneyline  -> NON SUPPORTE
    KXWNBATOTAL-26JUL19CONNPHX-169   sports_total      -> NON SUPPORTE
    KXWNBASPREAD-26JUL19CONNPHX-PHX4 sports_spread     -> NON SUPPORTE
    KXBTCD-26JUL1917-T64249.99       btc_daily         -> NON SUPPORTE
    KXBTC15M-26JUL191500-00          btc_15m           -> SUPPORTE
Ces rejets ne sont PAS un bug : aucune strategie sportive ni BTC-daily
reelle n'existe dans le depot. La correction est d'EXCLURE ces marches du
scan (univers cible), pas de les accepter.
"""
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from market_scanner import build_snapshot
from market_taxonomy import classify_market_type, MarketType
from strategy_router import StrategyRouter, BtcModelStrategy

NOW = datetime.now(timezone.utc)

REAL_CASES = [
    # (ticker, serie, type attendu, supporte, code attendu)
    ("KXWNBAGAME-26JUL20NYDAL-DAL", "KXWNBAGAME",
     MarketType.SPORTS_MONEYLINE, False, "UNSUPPORTED_MARKET_TYPE"),
    ("KXWNBATOTAL-26JUL19CONNPHX-169", "KXWNBATOTAL",
     MarketType.SPORTS_TOTAL, False, "UNSUPPORTED_MARKET_TYPE"),
    ("KXWNBASPREAD-26JUL19CONNPHX-PHX4", "KXWNBASPREAD",
     MarketType.SPORTS_SPREAD, False, "UNSUPPORTED_MARKET_TYPE"),
    ("KXBTCD-26JUL1917-T64249.99", "KXBTCD",
     MarketType.BTC_ABOVE_STRIKE_DAILY, False, "UNSUPPORTED_MARKET_TYPE"),
    ("KXBTC15M-26JUL191500-00", "KXBTC15M",
     MarketType.BTC_ABOVE_STRIKE_15M, True, None),
]


def snap(ticker, serie):
    return build_snapshot(
        {"ticker": ticker, "series_ticker": serie, "status": "open",
         "close_time": (NOW + timedelta(minutes=10)).isoformat(),
         "floor_strike": 64000,
         "yes_bid": 50, "yes_ask": 51, "no_bid": 49, "no_ask": 50,
         "volume": 5000, "open_interest": 2000, "liquidity": 8000},
        now=NOW)


def real_router():
    r = StrategyRouter()
    r.register(BtcModelStrategy(context_provider=lambda **k: None,
                                model_predict=lambda c: (None, "x")))
    return r


class TestRealTickersFromRailwayLogs(unittest.TestCase):
    def test_classification_and_resolution_verdicts(self):
        r = real_router()
        for ticker, serie, mt, supported, code in REAL_CASES:
            with self.subTest(ticker=ticker):
                s = snap(ticker, serie)
                self.assertEqual(s.market_type, mt,
                                 f"{ticker}: type {s.market_type}")
                d = r.resolve_detailed(s)
                if supported:
                    self.assertEqual(d.selected_strategy_name,
                                     "btc15m_model_v1", d)
                    self.assertIsNone(d.rejection_code)
                else:
                    self.assertIsNone(d.selected_strategy_name, d)
                    self.assertEqual(d.rejection_code, code, d)
                    # raison detaillee exigee, jamais un simple False
                    per = d.rejection_details.get("per_strategy", {})
                    self.assertIn("btc15m_model_v1", per)
                    self.assertIn(per["btc15m_model_v1"]["reason_code"],
                                  ("UNSUPPORTED_MARKET_TYPE",
                                   "UNSUPPORTED_SERIES",
                                   "UNSUPPORTED_CATEGORY"))

    def test_unsupported_series_are_not_in_targeted_universe(self):
        """La consequence correcte de la table de support : ces series ne
        font pas partie de l'univers cible derive du registre."""
        series = real_router().supported_series()
        self.assertEqual(series, ["KXBTC15M"])
        for _, serie, _, supported, _ in REAL_CASES:
            if not supported:
                self.assertNotIn(serie, series)


if __name__ == "__main__":
    unittest.main(verbosity=2)
