"""
test_router_declarations.py — les strategies declarent leurs series/types ;
le routeur les agrege (source unique du scanner) ; diagnostics structures.
Hors-ligne. BtcModelStrategy est instanciee avec fournisseurs injectes :
les modules btc_context / btc_probability_model ne sont PAS requis.
"""
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from strategy_router import StrategyRouter, BtcModelStrategy
from market_scanner import build_snapshot

NOW = datetime.now(timezone.utc)


def snap(ticker, serie):
    return build_snapshot(
        {"ticker": ticker, "series_ticker": serie, "status": "open",
         "close_time": (NOW + timedelta(minutes=10)).isoformat(),
         "yes_bid": 50, "yes_ask": 51, "no_bid": 49, "no_ask": 50,
         "volume": 5000, "open_interest": 2000, "liquidity": 8000},
        now=NOW)


def _btc():
    return BtcModelStrategy(context_provider=lambda **k: None,
                            model_predict=lambda c: (None, "x"))


class TestDeclarations(unittest.TestCase):
    def test_btc_strategy_declares_series_types_features(self):
        s = _btc()
        self.assertEqual(tuple(s.supported_series), ("KXBTC15M",))
        self.assertEqual(tuple(s.supported_market_types),
                         ("btc_above_strike_15m",))
        self.assertTrue(len(s.required_features) >= 1)

    def test_router_aggregates_series_from_active_strategies(self):
        r = StrategyRouter()
        r.register(_btc())
        self.assertEqual(r.supported_series(), ["KXBTC15M"])
        self.assertEqual(r.supported_market_types(),
                         ["btc_above_strike_15m"])

    def test_empty_router_declares_nothing(self):
        self.assertEqual(StrategyRouter().supported_series(), [])

    def test_declaration_never_widens_supports(self):
        """Les declarations servent au scanner ; supports() reste le verrou:
        un marche hors serie est refuse meme si sa categorie est Crypto."""
        s = _btc()
        self.assertFalse(s.supports(snap("KXBTCD-26JUL19-T64000", "KXBTCD")))
        self.assertTrue(s.supports(snap("KXBTC15M-26JUL191500-00",
                                        "KXBTC15M")))


class TestResolveDetailed(unittest.TestCase):
    def test_no_match_diagnostic(self):
        r = StrategyRouter()
        r.register(_btc())
        d = r.resolve_detailed(snap("KXWNBATOTAL-X", "KXWNBATOTAL"))
        self.assertEqual(d.rejection_code, "UNSUPPORTED_MARKET_TYPE")
        per = d.rejection_details["per_strategy"]["btc15m_model_v1"]
        self.assertEqual(per["reason_code"], "UNSUPPORTED_CATEGORY")
        self.assertEqual(d.compatible_strategy_names, [])
        self.assertEqual(d.rejection_details["registered_series"], ["KXBTC15M"])
        self.assertEqual(d.market_type, "sports_total")
        self.assertIsNone(d.selected_strategy_name)

    def test_single_match_diagnostic(self):
        r = StrategyRouter()
        r.register(_btc())
        d = r.resolve_detailed(snap("KXBTC15M-26JUL191500-00", "KXBTC15M"))
        self.assertIsNone(d.rejection_code)
        self.assertEqual(d.selected_strategy_name, "btc15m_model_v1")

    def test_detailed_agrees_with_resolve(self):
        r = StrategyRouter()
        r.register(_btc())
        for tk, serie in (("KXBTC15M-A", "KXBTC15M"),
                          ("KXWNBATOTAL-B", "KXWNBATOTAL")):
            s = snap(tk, serie)
            strat, why = r.resolve(s)
            d = r.resolve_detailed(s)
            self.assertEqual(d.rejection_code is None, why is None)
            self.assertEqual(d.selected_strategy_name,
                             getattr(strat, "name", None))


if __name__ == "__main__":
    unittest.main(verbosity=2)
