ERRATA: le README du bundle v2 affirmait market_taxonomy.py 'INCHANGE' ; c'etait inexact (enum MarketType deja ajoutee). Ce bundle v3 remplace integralement le v2.
