"""
test_integration_btc15m_path.py — chaine complete SANS ordre :
    API mock -> recuperation ciblee de KXBTC15M -> normalisation (snapshot)
    -> classification btc_above_strike_15m -> resolution de strategie
    -> features (strike, minutes_remaining) -> model_probability
Preuve exigee : eligible > 0, strategy_supported > 0, model_probability > 0.

AVERTISSEMENT D'HONNETETE (a lire) :
1) market_ranker.py n'a PAS ete fourni dans les fichiers uploades. Ce test
   injecte un STUB de ranker (sys.modules) clairement etiquete, qui marque
   eligibles les snapshots recus du pipeline. Il prouve le chemin
   scanner -> taxonomie -> routeur -> modele -> portes edge/EV, PAS le
   comportement du vrai ranker. Relancer test_repo_integrity/run_tests.py
   dans le depot complet apres remplacement des fichiers.
2) btc_context.py / btc_probability_model.py n'ont pas ete fournis : le
   modele est un STUB deterministe injecte (p_yes=0.65, confiance 0.8).
   Ce test prouve le ROUTAGE et les PORTES, pas le modele BTC reel.
"""
import json
import os
import sys
import types
import unittest
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

# ── STUB market_ranker (voir avertissement n.1) — installe AVANT l'import
# du pipeline, qui fait `from market_ranker import run_ranking, RankConfig`.
if "market_ranker" not in sys.modules:
    _stub = types.ModuleType("market_ranker")

    class RankConfig:                                    # signature minimale
        MIN_BOOK_OBSERVATIONS = 0
        HISTORY_FILE = "/tmp/stub_h.json"
        RANKINGS_FILE = "/tmp/stub_rk.json"
        REPORT_FILE = "/tmp/stub_rr.json"

    class _Score:
        def __init__(self, s):
            self.ticker = s.ticker
            self.category = s.category
            self.eligible = bool(s.included)
            self.exclusion_reason = s.exclusion_reason
            self.total_score = 80.0
            self.fill_probability_score = 80.0

    def run_ranking(client, scan_cfg=None, cfg=None, save=True,
                    snapshots=None):
        assert snapshots is not None, \
            "le pipeline doit fournir SES snapshots au ranker"
        scores = [_Score(s) for s in snapshots]
        return {"scores": scores,
                "report": {"markets_scored": len(scores),
                           "eligible": sum(1 for q in scores if q.eligible),
                           "excluded_by_reason": {}}}

    _stub.RankConfig = RankConfig
    _stub.run_ranking = run_ranking
    _stub.IS_TEST_STUB = True
    sys.modules["market_ranker"] = _stub

from market_scanner import ScanConfig
from strategy_router import (StrategyRouter, BtcModelStrategy, GateConfig)
from opportunity_pipeline import MarketOpportunityPipeline

NOW = datetime.now(timezone.utc)


class MockKalshiAPI:
    """KXBTC15M servi UNIQUEMENT via le filtre serveur series_ticker (comme
    le prouve la panne prod : le crawl general ne les atteignait pas)."""
    def __init__(self):
        self.calls = []

    def _req(self, method, path, params=None, **kw):
        assert path == "/markets", path
        p = dict(params or {})
        self.calls.append(p)
        if p.get("series_ticker") == "KXBTC15M" and not p.get("cursor"):
            return {"markets": [
                {"ticker": "KXBTC15M-26JUL191500-00",
                 "series_ticker": "KXBTC15M", "status": "open",
                 "title": "BTC above 64,000 at 15:00?",
                 "close_time": (NOW + timedelta(minutes=10)).isoformat(),
                 "floor_strike": 64000,
                 "yes_bid": 50, "yes_ask": 51, "no_bid": 49, "no_ask": 50,
                 "volume": 5000, "open_interest": 2000, "liquidity": 8000},
            ], "cursor": None}
        return {"markets": [], "cursor": None}

    def _log_raw_once(self, *a):
        pass

    def create_order(self, *a, **k):
        raise AssertionError("AUCUN ordre ne doit etre cree par ce test")


class _Ctx:                                   # contexte BTC minimal injecte
    valid = True
    spot = 64050.0
    strike = 64000.0


def _stub_model(ctx):
    """STUB deterministe (voir avertissement n.2)."""
    return ({"probability_yes": 0.65, "probability_no": 0.35,
             "confidence": 0.8, "calibrated": False,
             "model_version": "STUB-integration-test",
             "reason": "stub deterministe pour test de routage",
             "features": {}}, None)


def _pipeline(cli):
    router = StrategyRouter()
    router.register(BtcModelStrategy(
        context_provider=lambda **k: _Ctx(),
        model_predict=_stub_model))
    cfg = ScanConfig()
    cfg.PRIORITY_SERIES = []                 # rempli par le pipeline depuis
    cfg.GENERAL_CRAWL_ENABLED = False        # router.supported_series()
    cfg.UNIVERSE_FILE = "/tmp/it_u.json"
    cfg.REPORT_FILE = "/tmp/it_r.json"
    return MarketOpportunityPipeline(cli, router, gates=GateConfig(),
                                     scan_cfg=cfg, save_artifacts=False)


class TestFullBtc15mPath(unittest.TestCase):
    def test_end_to_end_no_order(self):
        cli = MockKalshiAPI()
        pipe = _pipeline(cli)
        res = pipe.run_cycle(max_accepted=1)
        rep = res["report"]

        # 1) l'univers a ete recupere par filtre serveur, sans crawl general
        self.assertTrue(any(c.get("series_ticker") == "KXBTC15M"
                            for c in cli.calls))
        self.assertTrue(all(c.get("series_ticker") for c in cli.calls))

        # 2) criteres d'acceptation exiges
        self.assertGreater(rep["eligible"], 0, rep)
        self.assertGreater(rep["strategy_supported"], 0, rep)
        self.assertGreater(rep["model_probability"], 0, rep)

        # 3) classification + routage traces
        tr = res.get("accepted") and pipe.last_traces[-1] or None
        self.assertEqual(rep["classified"], 1)
        self.assertEqual(rep["unknown_market_type"], 0)
        self.assertEqual(rep["rejections"].get("no_compatible_strategy", 0),
                         0)

        # 4) une decision complete existe, avec probabilite modele > 0
        self.assertEqual(len(res["accepted"]), 1)
        dec = res["accepted"][0]
        self.assertEqual(dec.strategy, "btc15m_model_v1")
        self.assertAlmostEqual(dec.model_probability, 0.65, places=9)
        self.assertGreater(dec.net_edge, 0)
        self.assertGreater(dec.net_ev, 0)
        # aucun ordre : create_order leverait (MockKalshiAPI)

    def test_reject_cache_and_deep_cap_metrics_present(self):
        cli = MockKalshiAPI()
        pipe = _pipeline(cli)
        rep = pipe.run_cycle(max_accepted=1)["report"]
        for k in ("deep_analysis_count", "deep_analysis_capped",
                  "reject_cache_hits", "reject_cache_size",
                  "max_deep_analyses_per_cycle"):
            self.assertIn(k, rep)

    def test_example_reports_written(self):
        """Genere les artefacts d'exemple exiges dans les livrables."""
        cli = MockKalshiAPI()
        pipe = _pipeline(cli)
        pipe.save_artifacts = False
        res = pipe.run_cycle(max_accepted=1)
        out = os.environ.get("EXAMPLE_REPORT_DIR")
        if out:
            from market_scanner import run_scan
            scan = run_scan(MockKalshiAPI(), cfg=pipe.scan_cfg, save=False)
            with open(os.path.join(out, "example_market_scanner_report.json"),
                      "w") as f:
                json.dump(scan["report"], f, indent=1)
            with open(os.path.join(out, "example_pipeline_report.json"),
                      "w") as f:
                json.dump(res["report"], f, indent=1, default=str)
        self.assertTrue(res["report"]["strategy_supported"] > 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
