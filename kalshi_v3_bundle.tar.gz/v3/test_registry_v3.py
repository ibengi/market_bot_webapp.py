"""
test_registry_v3.py — tests unitaires du registre (liste imposee 8A) :
registre vide / active / desactivee / type compatible / incompatible /
serie compatible / incompatible / donnees manquantes / enum vs string /
double enregistrement / plusieurs compatibles / selection deterministe.
Hors-ligne. Utilise les VRAIES classes du depot (aucun mock du registre).
"""
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from strategy_router import StrategyRouter, BtcModelStrategy
from market_taxonomy import MarketType, normalize_market_type
from market_scanner import build_snapshot

NOW = datetime.now(timezone.utc)


def snap(ticker, serie):
    return build_snapshot(
        {"ticker": ticker, "series_ticker": serie, "status": "open",
         "close_time": (NOW + timedelta(minutes=10)).isoformat(),
         "yes_bid": 50, "yes_ask": 51, "no_bid": 49, "no_ask": 50,
         "volume": 5000, "open_interest": 2000, "liquidity": 8000},
        now=NOW)


def _btc(**kw):
    s = BtcModelStrategy(context_provider=lambda **k: None,
                         model_predict=lambda c: (None, "x"))
    for k, v in kw.items():
        setattr(s, k, v)
    return s


class _S:
    def __init__(self, name, ok=True, priority=0, enabled=True):
        self.name, self._ok = name, ok
        self.priority, self.enabled = priority, enabled
        self.categories = ["Test"]
    def supports(self, s): return self._ok
    def evaluate(self, *a): return None


class TestRegistry8A(unittest.TestCase):
    def test_empty_registry_raises_explicitly(self):
        r = StrategyRouter()
        with self.assertRaises(RuntimeError) as cm:
            r.validate()
        self.assertIn("No active trading strategies registered",
                      str(cm.exception))

    def test_active_strategy_registered_and_boot_logged(self):
        r = StrategyRouter()
        r.register(_btc())
        self.assertTrue(r.validate())
        entries = r.log_boot()
        self.assertEqual(len(entries), 1)
        self.assertEqual(entries[0]["name"], "btc15m_model_v1")
        self.assertEqual(entries[0]["supported_series"], ["KXBTC15M"])
        self.assertEqual(entries[0]["supported_market_types"],
                         ["btc_above_strike_15m"])

    def test_disabled_strategy_not_routed_but_traced(self):
        r = StrategyRouter()
        r.register(_S("off", ok=True, enabled=False))
        self.assertEqual(r.strategies(), [])
        with self.assertRaises(RuntimeError) as cm:
            r.validate()
        self.assertIn("off", str(cm.exception))   # cause visible

    def test_env_flag_disables_btc_strategy(self):
        os.environ["BTC_STRATEGY_ENABLED"] = "false"
        try:
            r = StrategyRouter()
            r.register(_btc())
            self.assertEqual(r.strategies(), [])
        finally:
            del os.environ["BTC_STRATEGY_ENABLED"]

    def test_compatible_type_and_series(self):
        r = StrategyRouter(); r.register(_btc())
        strat, why = r.resolve(snap("KXBTC15M-26JUL191500-00", "KXBTC15M"))
        self.assertIsNone(why)
        self.assertEqual(strat.name, "btc15m_model_v1")

    def test_incompatible_type(self):
        r = StrategyRouter(); r.register(_btc())
        d = r.resolve_detailed(snap("KXWNBATOTAL-X", "KXWNBATOTAL"))
        self.assertEqual(d.rejection_code, "UNSUPPORTED_MARKET_TYPE")

    def test_incompatible_series_detailed_reason(self):
        s = _btc()
        # categorie Crypto, type btc DAILY -> raison type ; serie KXBTCD
        chk = s.supports_detailed(snap("KXBTCD-26JUL1917-T64249.99",
                                       "KXBTCD"))
        self.assertFalse(chk.supported)
        self.assertEqual(chk.reason_code, "UNSUPPORTED_MARKET_TYPE")
        self.assertEqual(chk.details["allowed_series"], ["KXBTC15M"])

    def test_missing_data_snapshot_without_attrs(self):
        class Bare:                       # snapshot minimal sans attributs
            ticker = "X"
        s = _btc()
        chk = s.supports_detailed(Bare())
        self.assertFalse(chk.supported)
        self.assertIn(chk.reason_code,
                      ("UNSUPPORTED_CATEGORY", "UNSUPPORTED_SERIES"))

    def test_enum_vs_string_equality(self):
        self.assertEqual(MarketType.SPORTS_TOTAL, "sports_total")
        self.assertIs(normalize_market_type("SPORTS_TOTAL"),
                      MarketType.SPORTS_TOTAL)
        sp = snap("KXBTC15M-A", "KXBTC15M")
        self.assertIs(normalize_market_type(sp.market_type),
                      MarketType.BTC_ABOVE_STRIKE_15M)

    def test_duplicate_registration_refused(self):
        r = StrategyRouter()
        a = _btc()
        r.register(a)
        r.register(a)                              # meme objet
        r.register(_btc())                         # meme nom
        self.assertEqual(len(r.strategies()), 1)

    def test_multiple_compatible_equal_priority_is_ambiguous(self):
        r = StrategyRouter()
        r.register(_S("a", priority=1)); r.register(_S("b", priority=1))
        strat, why = r.resolve(snap("X-1", "X"))
        self.assertIsNone(strat)
        self.assertEqual(why, "ambiguous_strategy_match")
        d = r.resolve_detailed(snap("X-1", "X"))
        self.assertEqual(d.rejection_code, "MULTIPLE_COMPATIBLE_STRATEGIES")

    def test_deterministic_selection_by_priority(self):
        for order in ((1, 5), (5, 1)):             # independant de l'ordre
            r = StrategyRouter()
            r.register(_S("p%d" % order[0], priority=order[0]))
            r.register(_S("p%d" % order[1], priority=order[1]))
            strat, why = r.resolve(snap("X-1", "X"))
            self.assertIsNone(why)
            self.assertEqual(strat.name, "p5")

    def test_resolve_detailed_agrees_with_resolve(self):
        r = StrategyRouter(); r.register(_btc())
        for tk, serie in (("KXBTC15M-A", "KXBTC15M"),
                          ("KXWNBAGAME-B", "KXWNBAGAME")):
            s = snap(tk, serie)
            strat, why = r.resolve(s)
            d = r.resolve_detailed(s)
            self.assertEqual(d.selected_strategy_name,
                             getattr(strat, "name", None))
            self.assertEqual(d.rejection_code is None, why is None)


if __name__ == "__main__":
    unittest.main(verbosity=2)
