"""
test_scanner_v2.py — scanner v2 : univers cible par defaut, crawl general
opt-in, plafonds, fenetre temporelle, dedup, metriques, benchmark.
Hors-ligne, deterministe, aucun reseau.
"""
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from market_scanner import (ScanConfig, fetch_universe, fetch_all_markets,
                            run_scan)

NOW = datetime.now(timezone.utc)


def _mkt(ticker, serie, mins=10, liq=8000, **extra):
    m = {"ticker": ticker, "series_ticker": serie, "status": "open",
         "close_time": (NOW + timedelta(minutes=mins)).isoformat(),
         "yes_bid": 50, "yes_ask": 51, "no_bid": 49, "no_ask": 50,
         "volume": 5000, "open_interest": 2000, "liquidity": liq}
    m.update(extra)
    return m


class HugeUniverseClient:
    """Simule l'API : crawl general = pages sans fin de marches sportifs ;
    KXBTC15M renvoye UNIQUEMENT via le filtre serveur series_ticker."""
    def __init__(self):
        self.calls = []

    def _req(self, method, path, params=None, **kw):
        assert path == "/markets"
        p = dict(params or {})
        self.calls.append(p)
        limit = int(p.get("limit", 200))
        if p.get("series_ticker") == "KXBTC15M":
            if p.get("cursor"):
                return {"markets": [], "cursor": None}
            return {"markets": [
                _mkt("KXBTC15M-26JUL191500-00", "KXBTC15M",
                     floor_strike=64000),
                _mkt("KXBTC15M-26JUL191515-00", "KXBTC15M", mins=25,
                     floor_strike=64000)], "cursor": None}
        if p.get("series_ticker"):
            return {"markets": [], "cursor": None}
        page = int(p.get("cursor") or 0)
        return {"markets": [_mkt(f"KXWNBATOTAL-P{page}-N{i}", "KXWNBATOTAL")
                            for i in range(limit)],
                "cursor": str(page + 1)}

    def _log_raw_once(self, *a):
        pass


def _cfg(**kw):
    cfg = ScanConfig()
    cfg.PAGE_LIMIT = 5
    cfg.MAX_PAGES = 3
    cfg.PRIORITY_MAX_PAGES = 3
    cfg.PRIORITY_SERIES = []
    cfg.GENERAL_CRAWL_ENABLED = False
    cfg.MAX_MARKETS_PER_CYCLE = 300
    cfg.LOOKAHEAD_HOURS = 24.0
    cfg.UNIVERSE_FILE = "/tmp/u_v2.json"
    cfg.REPORT_FILE = "/tmp/r_v2.json"
    for k, v in kw.items():
        setattr(cfg, k, v)
    return cfg


class Test1_BugReproduced_GeneralCrawlTruncated(unittest.TestCase):
    def test_truncated_crawl_misses_btc15m(self):
        cli = HugeUniverseClient()
        markets, pages, errors = fetch_all_markets(cli, cfg=_cfg())
        self.assertEqual(pages, 3)                       # garde-fou atteint
        self.assertFalse(any(m["ticker"].startswith("KXBTC15M")
                             for m in markets),
                         "reproduction: le crawl tronque ne voit pas KXBTC15M")


class Test2_TargetedUniverseIsDefault(unittest.TestCase):
    def test_no_general_crawl_by_default(self):
        cli = HugeUniverseClient()
        uni = fetch_universe(cli, cfg=_cfg(PRIORITY_SERIES=["KXBTC15M"]))
        self.assertFalse(uni["general_crawl_enabled"])
        # AUCUN appel /markets sans series_ticker
        self.assertTrue(all(c.get("series_ticker") for c in cli.calls))
        tickers = [m["ticker"] for m in uni["markets"]]
        self.assertEqual(sorted(tickers),
                         ["KXBTC15M-26JUL191500-00",
                          "KXBTC15M-26JUL191515-00"])

    def test_general_crawl_opt_in_with_dedup(self):
        cli = HugeUniverseClient()
        uni = fetch_universe(cli, cfg=_cfg(PRIORITY_SERIES=["KXBTC15M"],
                                           GENERAL_CRAWL_ENABLED=True))
        tickers = [m["ticker"] for m in uni["markets"]]
        self.assertIn("KXBTC15M-26JUL191500-00", tickers)
        self.assertEqual(len(tickers), len(set(tickers)), "doublons")
        self.assertTrue(any(not c.get("series_ticker") for c in cli.calls))

    def test_empty_priority_and_no_crawl_yields_empty_universe(self):
        cli = HugeUniverseClient()
        uni = fetch_universe(cli, cfg=_cfg())
        self.assertEqual(uni["markets"], [])
        self.assertEqual(uni["api_calls"], 0)

    def test_missing_priority_series_is_flagged(self):
        cli = HugeUniverseClient()
        uni = fetch_universe(cli, cfg=_cfg(PRIORITY_SERIES=["KXNOPE"]))
        self.assertEqual(uni["priority_series_empty"], ["KXNOPE"])


class Test3_CapsAndLookahead(unittest.TestCase):
    def test_max_markets_per_cycle_keeps_best_liquidity(self):
        class Cli:
            def _req(self, m, p, params=None, **kw):
                pr = dict(params or {})
                if pr.get("cursor"):
                    return {"markets": [], "cursor": None}
                mk = [_mkt(f"KXBTC15M-A{i}", "KXBTC15M", liq=1000 + i,
                           floor_strike=64000) for i in range(10)]
                return {"markets": mk, "cursor": None}
            def _log_raw_once(self, *a): pass
        res = run_scan(Cli(), cfg=_cfg(PRIORITY_SERIES=["KXBTC15M"],
                                       MAX_MARKETS_PER_CYCLE=4), save=False)
        rep = res["report"]
        self.assertEqual(rep["total_markets_received"], 10)
        self.assertEqual(rep["markets_kept"], 4)
        self.assertEqual(rep["capped_by_max_markets"], 6)
        # garde les plus liquides
        kept = {s.ticker for s in res["snapshots"]}
        self.assertEqual(kept, {"KXBTC15M-A9", "KXBTC15M-A8",
                                "KXBTC15M-A7", "KXBTC15M-A6"})

    def test_lookahead_excludes_far_markets(self):
        class Cli:
            def _req(self, m, p, params=None, **kw):
                pr = dict(params or {})
                if pr.get("cursor"):
                    return {"markets": [], "cursor": None}
                return {"markets": [
                    _mkt("KXBTC15M-NEAR", "KXBTC15M", mins=30,
                         floor_strike=64000),
                    _mkt("KXBTC15M-FAR", "KXBTC15M", mins=60 * 48,
                         floor_strike=64000)], "cursor": None}
            def _log_raw_once(self, *a): pass
        res = run_scan(Cli(), cfg=_cfg(PRIORITY_SERIES=["KXBTC15M"]),
                       save=False)
        by = {s.ticker: s for s in res["snapshots"]}
        self.assertTrue(by["KXBTC15M-NEAR"].included)
        self.assertEqual(by["KXBTC15M-FAR"].exclusion_reason,
                         "beyond_lookahead")


class Test4_Benchmark_Before_After(unittest.TestCase):
    """BENCHMARK SYNTHETIQUE (mock API deterministe, PAS des donnees reelles).
    'Avant' reproduit la config prod observee : crawl general, 200 pages x
    200 = 40 000 marches recus et transformes en snapshots par cycle.
    'Apres' : univers cible par les series des strategies actives."""
    def test_at_least_90pct_reduction(self):
        cli_before = HugeUniverseClient()
        before = run_scan(cli_before,
                          cfg=_cfg(GENERAL_CRAWL_ENABLED=True,
                                   PRIORITY_SERIES=[],
                                   PAGE_LIMIT=200, MAX_PAGES=200,
                                   MAX_MARKETS_PER_CYCLE=0,
                                   LOOKAHEAD_HOURS=0),
                          save=False)["report"]
        cli_after = HugeUniverseClient()
        after = run_scan(cli_after,
                         cfg=_cfg(PRIORITY_SERIES=["KXBTC15M"]),
                         save=False)["report"]
        self.assertEqual(before["total_markets_received"], 40000)
        self.assertEqual(after["total_markets_received"], 2)
        red_markets = 1 - after["total_markets_received"] \
            / before["total_markets_received"]
        red_api = 1 - after["api_calls"] / before["api_calls"]
        self.assertGreaterEqual(red_markets, 0.90)
        self.assertGreaterEqual(red_api, 0.90)
        print(f"\n[BENCHMARK synthetique] marches recus: "
              f"{before['total_markets_received']} -> "
              f"{after['total_markets_received']} "
              f"(-{red_markets:.2%}) | appels API: {before['api_calls']} -> "
              f"{after['api_calls']} (-{red_api:.2%})")


if __name__ == "__main__":
    unittest.main(verbosity=2)
