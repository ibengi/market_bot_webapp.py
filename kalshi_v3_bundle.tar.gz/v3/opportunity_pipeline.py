"""
opportunity_pipeline.py — v1 (2026-07-11)
MarketOpportunityPipeline : SCANNER -> RANKER -> ROUTEUR -> PORTES EDGE/EV.

Utilise a CHAQUE cycle normal du bot (plus seulement --scan-only/--rank-only).
Ce module ne place AUCUN ordre : il produit des SignalDecision acceptees,
classees par qualite, que le moteur d'execution consomme ensuite (avec sa
propre relecture du carnet et ses portes de risque).

Rapport de cycle ecrit par l'appelant (cycle_report.json) :
    scanned, scanner_included, ranker_eligible, strategy_supported,
    positive_edge, orders_submitted, fills_confirmed, rejections{...}
"""

import logging
from dataclasses import asdict
from typing import Optional, Callable

from market_scanner import run_scan, ScanConfig, MarketSnapshot
from market_taxonomy import classification_report
from market_ranker import run_ranking, RankConfig
from strategy_router import (StrategyRouter, GateConfig, SignalDecision,
                             evaluate_candidate)

log = logging.getLogger("PIPELINE")


class MarketOpportunityPipeline:
    def __init__(self, client, router: StrategyRouter,
                 gates: GateConfig = None,
                 scan_cfg: ScanConfig = None,
                 rank_cfg: RankConfig = None,
                 fresh_book_fn: Optional[Callable] = None,
                 save_artifacts: bool = True,
                 observer: Optional[Callable] = None):
        """observer(snapshot, book, decision) : appele pour CHAQUE candidat
        evalue (accepte ou rejete) — utilise par le journal shadow."""
        """fresh_book_fn(ticker) -> (fresh_market_dict, normalized_book|None)
        Fournie par le moteur : relecture du carnet JUSTE avant decision.
        Si None, le carnet du snapshot (age du scan) est utilise — reserve
        aux tests."""
        self.client = client
        self.router = router
        self.gates = gates or GateConfig()
        self.scan_cfg = scan_cfg or ScanConfig()
        self.rank_cfg = rank_cfg or RankConfig()
        self.fresh_book_fn = fresh_book_fn
        self.save_artifacts = save_artifacts
        self.observer = observer
        # ── v2 (2026-07-19) ──────────────────────────────────────────────────
        # Plafond d'analyses profondes par cycle (niveau 3) et cache TTL des
        # rejets : un marche rejete pour une raison PERMANENTE (aucune
        # strategie ne le supportera jamais pendant sa vie) n'est pas
        # re-analyse a chaque cycle ; une raison temporaire est reevaluee
        # apres TTL.
        import os as _os
        self.max_deep_analyses = int(_os.getenv(
            "SCAN_MAX_DEEP_ANALYSES_PER_CYCLE", "50"))
        self.reject_ttl_permanent = float(_os.getenv(
            "PIPELINE_REJECT_TTL_PERMANENT_S", "3600"))
        self.reject_ttl_temporary = float(_os.getenv(
            "PIPELINE_REJECT_TTL_TEMPORARY_S", "120"))
        self._reject_cache = {}          # ticker -> (reason, expires_epoch)
    _PERMANENT_REJECTS = ("no_compatible_strategy", "ambiguous_strategy_match")

    def _reject_cached(self, ticker, now_epoch):
        ent = self._reject_cache.get(ticker)
        if not ent:
            return None
        reason, exp = ent
        if now_epoch >= exp:
            del self._reject_cache[ticker]
            return None
        return reason

    def _cache_reject(self, snap, reason, now_epoch):
        if reason in self._PERMANENT_REJECTS:
            mins = getattr(snap, "minutes_remaining", None)
            ttl = min(self.reject_ttl_permanent,
                      mins * 60.0) if mins else self.reject_ttl_permanent
        else:
            ttl = self.reject_ttl_temporary
        self._reject_cache[snap.ticker] = (reason, now_epoch + max(ttl, 1.0))

    # ── un cycle complet ─────────────────────────────────────────────────
    def run_cycle(self, max_accepted: int = 1,
                  skip_ticker_fn: Optional[Callable] = None) -> dict:
        """Retourne {"accepted": [SignalDecision...], "report": {...}}.
        Parcourt les candidats du meilleur au moins bon ; n'abandonne pas
        au premier rejet ; s'arrete a max_accepted ou epuisement."""
        # ── CORRECTION DESYNCHRONISATION (2026-07-12) ──
        # Avant : le pipeline dependait du retour "snapshots" de
        # market_ranker.run_ranking ; toute version anterieure du ranker
        # (sans cette cle) faisait tomber 100% des eligibles en
        # snapshot_missing. Desormais le pipeline est PROPRIETAIRE du scan :
        # il scanne lui-meme, garde ses snapshots, et les FOURNIT au ranker
        # (parametre `snapshots` present dans toutes les versions du ranker).
        # Le couplage par valeur de retour est supprime ; un melange de
        # versions de fichiers ne peut plus provoquer cette panne.
        # ── v2 : l'univers du scanner derive des strategies ACTIVES ──────────
        # (source unique : router.supported_series() ; surchargable par env
        # SCANNER_PRIORITY_SERIES deja lue dans ScanConfig). Aucune liste de
        # series codee en dur cote scanner.
        if not getattr(self.scan_cfg, "PRIORITY_SERIES", None):
            try:
                self.scan_cfg.PRIORITY_SERIES = self.router.supported_series()
            except Exception:
                pass
        # Repli COMPATIBILITE : si les strategies actives ne declarent aucune
        # serie (strategies heritees/stubs de test) et que le crawl general
        # est desactive, l'univers serait vide. On active alors le crawl
        # general pour CE pipeline, avec avertissement. Les strategies
        # reelles (BtcModelStrategy) declarent leurs series -> mode cible.
        if not self.scan_cfg.PRIORITY_SERIES \
                and not self.scan_cfg.GENERAL_CRAWL_ENABLED:
            log.warning("[PIPELINE] Aucune serie declaree par les strategies "
                        "actives et crawl general desactive -- activation du "
                        "crawl general de repli (declarer supported_series "
                        "sur les strategies pour le mode cible).")
            self.scan_cfg.GENERAL_CRAWL_ENABLED = True
        scan = run_scan(self.client, cfg=self.scan_cfg,
                        save=self.save_artifacts)
        own_snapshots = scan["snapshots"]
        # ── v3 : PRE-FILTRAGE REGISTRE AVANT LE RANKING ──────────────────────
        # Ordre impose : normalisation -> classification -> compatibilite
        # registre -> ranking. Un marche qu'aucune strategie active ne
        # supporte n'atteint plus le ranking profond. resolve() est local et
        # sans reseau ; les compteurs classified/unknown portent sur TOUS les
        # marches retenus par le scanner.
        import time as _time
        now_epoch = _time.time()
        rejections = {}
        cache_hits = 0
        n_classified = 0
        n_unknown_type = 0
        n_ambiguous = 0
        n_prefiltered = 0
        self.last_traces = []
        prerank = []
        for s in own_snapshots:
            mt = getattr(s, "market_type", "unknown")
            if not s.included:
                continue
            log.info(f"[CLASSIFY] {s.ticker} category={s.category} "
                     f"market_type={mt}")
            if mt == "unknown":
                n_unknown_type += 1
            else:
                n_classified += 1
            cached = self._reject_cached(s.ticker, now_epoch)
            if cached is not None:
                cache_hits += 1
                rejections[cached] = rejections.get(cached, 0) + 1
                continue
            pre_strat, pre_why = self.router.resolve(s)
            if pre_strat is None:
                n_prefiltered += 1
                if pre_why == "ambiguous_strategy_match":
                    n_ambiguous += 1
                rejections[pre_why] = rejections.get(pre_why, 0) + 1
                self._cache_reject(s, pre_why, now_epoch)
                diag = None
                if hasattr(self.router, "resolve_detailed"):
                    try:
                        diag = self.router.resolve_detailed(s)
                        log.info(
                            f"[STRATEGY_RESOLUTION] ticker={s.ticker} "
                            f"market_type={diag.market_type} "
                            f"registered_strategies="
                            f"{diag.registered_strategy_names} "
                            f"compatible_strategies="
                            f"{diag.compatible_strategy_names} "
                            f"selected_strategy={diag.selected_strategy_name} "
                            f"code={diag.rejection_code}")
                    except Exception:
                        diag = None
                log.info(f"[REJECT] {s.ticker} {pre_why} (avant ranking)")
                self.last_traces.append({
                    "ticker": s.ticker, "ranker_score": None,
                    "category": s.category, "market_type": mt,
                    "strategy": None, "model_probability": None,
                    "confidence": None, "market_probability": None,
                    "gross_edge": None, "estimated_fees": None,
                    "slippage": None, "net_edge": None, "net_ev": None,
                    "decision": "REJECT", "reject_reason": pre_why,
                    "router_diagnostic":
                        (asdict(diag) if diag is not None else None)})
                continue
            prerank.append(s)
        n_supported_by_registry = len(prerank)
        n_unsupported_before_ranking = n_prefiltered
        try:
            ranking = run_ranking(self.client, scan_cfg=self.scan_cfg,
                                  cfg=self.rank_cfg, save=self.save_artifacts,
                                  snapshots=prerank)
        except TypeError:
            # market_ranker ANCIEN (sans parametre `snapshots`) deploye a
            # cote d'un pipeline recent : mode degrade tolere -- le ranker
            # re-scanne en interne (cout: un scan de plus), mais la
            # correspondance se fait sur NOS snapshots, par ticker. Plus
            # aucun snapshot_missing possible du fait d'un melange de
            # versions.
            log.warning("[PIPELINE] market_ranker.py ANCIEN detecte (pas de "
                        "parametre 'snapshots') -- mode degrade actif. "
                        "Mettre a jour market_ranker.py pour eviter le "
                        "double scan.")
            ranking = run_ranking(self.client, scan_cfg=self.scan_cfg,
                                  cfg=self.rank_cfg, save=self.save_artifacts)
        scores = ranking["scores"]
        rep_rank = ranking["report"]
        snaps_by_ticker = {s.ticker: s for s in own_snapshots}
        log.info(f"[PIPELINE] snapshots (scan pipeline): "
                 f"{len(snaps_by_ticker)} | scores: {len(scores)} "
                 f"| eligibles: {rep_rank['eligible']}")
        if rep_rank["eligible"] > 0 and not snaps_by_ticker:
            log.error("[PIPELINE] INCOHERENCE INTERNE: scores eligibles sans "
                      "snapshots issus du scan du pipeline -- a signaler.")

        rejections_prerank = dict(rejections)   # deja comptes avant ranking
        accepted = []
        examined = 0
        supported = 0
        positive_edge = 0
        with_model_prob = 0
        positive_net_ev = 0

        eligible = [q for q in scores if q.eligible]
        deep_capped = 0
        for q in eligible:
            if len(accepted) >= max_accepted:
                break
            if examined >= self.max_deep_analyses:
                deep_capped += 1
                continue
            cached = self._reject_cached(q.ticker, now_epoch)
            if cached is not None:
                cache_hits += 1
                rejections[cached] = rejections.get(cached, 0) + 1
                continue
            snap = snaps_by_ticker.get(q.ticker)
            if snap is None:
                rejections["snapshot_missing"] = \
                    rejections.get("snapshot_missing", 0) + 1
                log.info(f"[REJECT] {q.ticker}: snapshot_missing "
                         f"(desynchronisation ranker/pipeline)")
                continue
            snap.quality = q                       # visible pour les portes
            examined += 1
            log.info(f"[RANK] {q.ticker} | cat={q.category} "
                     f"| score={q.total_score}")
            mt = getattr(snap, "market_type", "unknown")

            if skip_ticker_fn and skip_ticker_fn(q.ticker):
                rejections["already_open"] = rejections.get("already_open", 0) + 1
                continue

            # Resolution deja effectuee AVANT le ranking (prerank) ; ici on
            # re-resout par securite (idempotent, local) — si l'etat a change
            # entre prerank et maintenant, la raison est comptee normalement.
            pre_strat, pre_why = self.router.resolve(snap)
            if pre_strat is None:
                rejections[pre_why] = rejections.get(pre_why, 0) + 1
                log.info(f"[REJECT] {q.ticker} {pre_why}")
                continue
            log.info(f"[STRATEGY_SELECTED] ticker={q.ticker} "
                     f"market_type={mt} strategy="
                     f"{getattr(pre_strat, 'name', '?')}")

            # carnet FRAIS si le moteur fournit la fonction, sinon snapshot
            if self.fresh_book_fn:
                fresh_market, book = self.fresh_book_fn(q.ticker)
            else:
                fresh_market = snap.raw_market
                book = self._book_from_snapshot(snap)

            dec = evaluate_candidate(snap, fresh_market or {}, book,
                                     self.router, self.gates)
            log.info(f"[ROUTER] {q.ticker} -> strategie="
                     f"{dec.strategy or 'AUCUNE'}")
            if dec.model_probability is not None:
                log.info(f"[MODEL] {q.ticker} p_modele="
                         f"{dec.model_probability:.4f} conf={dec.confidence}")
                log.info(f"[MODEL_PROBABILITY] ticker={q.ticker} "
                         f"probability={dec.model_probability:.4f}")
            if dec.gross_edge is not None:
                def _f(v):     # tolerant: net/ev absents si rejet en amont
                    return f"{v:+.4f}" if isinstance(v, (int, float)) else "n/a"
                log.info(f"[EDGE] {q.ticker} p_marche="
                         f"{dec.market_probability:.4f} "
                         f"brut={_f(dec.gross_edge)} "
                         f"frais={dec.estimated_fees} slip={dec.expected_slippage} "
                         f"net={_f(dec.net_edge)} ev={_f(dec.net_ev)}")
            log.info(f"[{'EXECUTION-CANDIDAT' if dec.accepted else 'REJECT'}] "
                     f"{q.ticker}"
                     f"{'' if dec.accepted else ': ' + str(dec.rejection_reason)}")
            self.last_traces.append({
                "ticker": q.ticker, "ranker_score": q.total_score,
                "category": q.category,
                "strategy": dec.strategy,
                "model_probability": dec.model_probability,
                "confidence": dec.confidence,
                "market_probability": dec.market_probability,
                "gross_edge": dec.gross_edge,
                "estimated_fees": dec.estimated_fees,
                "slippage": dec.expected_slippage,
                "net_edge": dec.net_edge, "net_ev": dec.net_ev,
                "decision": "ACCEPT" if dec.accepted else "REJECT",
                "reject_reason": dec.rejection_reason,
                # ── champs shadow exiges : un signal accepte n'est PAS un
                # ordre ; l'envoi reel est decide par le moteur (et bloque en
                # SHADOW_MODE). Au niveau pipeline, actual_submission est
                # TOUJOURS False.
                "signal_accepted": bool(dec.accepted),
                "would_submit": bool(dec.accepted),
                "actual_submission": False,
                "risk_passed": None})   # evalue ensuite par le moteur
            if dec.accepted:
                import json as _json
                log.info("[SHADOW_DECISION] " + _json.dumps({
                    "ticker": dec.ticker,
                    "market_type": getattr(snap, "market_type", None),
                    "strategy": dec.strategy,
                    "side": dec.side,
                    "model_probability": dec.model_probability,
                    "market_price": dec.market_probability,
                    "gross_edge": dec.gross_edge,
                    "estimated_fees": dec.estimated_fees,
                    "estimated_slippage": dec.expected_slippage,
                    "net_ev": dec.net_ev,
                    "risk_passed": None,
                    "would_submit": True,
                    "actual_submission": False}, ensure_ascii=False))
            if self.observer:
                try:
                    self.observer(snap, book, dec)
                except Exception as e:
                    log.warning(f"observer: {e}")
            if dec.strategy:
                supported += 1
            if dec.model_probability is not None:
                with_model_prob += 1
            if dec.gross_edge is not None and dec.gross_edge > 0:
                positive_edge += 1
            if dec.net_ev is not None and dec.net_ev > 0:
                positive_net_ev += 1
            if dec.accepted:
                accepted.append(dec)
                log.info(f"[PIPELINE] CANDIDAT VALIDE {dec.ticker} "
                         f"{dec.side.upper()} @ {dec.entry_price_cents}c | "
                         f"edge_net={dec.net_edge:+.3f} ev_net={dec.net_ev:+.3f} "
                         f"strat={dec.strategy}")
            else:
                rejections[dec.rejection_reason] = \
                    rejections.get(dec.rejection_reason, 0) + 1
                self._cache_reject(snap, dec.rejection_reason, now_epoch)

        # les non-eligibles du ranker comptent aussi dans les rejets
        for q in scores:
            if not q.eligible and q.exclusion_reason:
                rejections[q.exclusion_reason] = \
                    rejections.get(q.exclusion_reason, 0) + 1

        report = {
            # ── volumes (ordre du pipeline) ──
            "api_markets_received":
                scan["report"].get("total_markets_received"),
            "markets_after_dedup":
                scan["report"].get("total_markets_received"),  # dedup au fetch
            "markets_kept_after_cap": scan["report"].get("markets_kept"),
            "markets_supported_by_registry": n_supported_by_registry,
            "unsupported_before_ranking": n_unsupported_before_ranking,
            "ranked_markets": rep_rank["markets_scored"],
            "scanned": rep_rank["markets_scored"],
            "scanner_included": rep_rank["markets_scored"]
                                - sum(v for k, v in
                                      rep_rank["excluded_by_reason"].items()
                                      if k in ("no_liquidity", "expired",
                                               "closes_too_soon", "invalid_book",
                                               "spread_too_wide", "low_volume",
                                               "unsupported",
                                               "beyond_lookahead")),
            "valid": None,   # renseigne ci-dessous (= inclus par le scanner)
            "ranker_eligible": rep_rank["eligible"],
            "eligible": rep_rank["eligible"],
            "candidates_examined": examined,
            "deep_analysis_count": examined,
            "deep_analysis_capped": deep_capped,
            "max_deep_analyses_per_cycle": self.max_deep_analyses,
            "reject_cache_hits": cache_hits,
            "reject_cache_size": len(self._reject_cache),
            "classified": n_classified,
            "unknown_market_type": n_unknown_type,
            "prefiltered_no_strategy": n_prefiltered,
            "ambiguous_strategy_match": n_ambiguous,
            "strategy_supported": supported,
            "model_probability": with_model_prob,
            "positive_edge": positive_edge,
            "positive_net_ev": positive_net_ev,
            # ── clarification exigee : "accepted" == SIGNAL accepte par les
            # portes edge/EV, PAS un ordre. Les etapes suivantes sont
            # completees par le moteur d'execution ; signal_accepted=1 avec
            # risk_passed=0 signifie "signal valide, controles de risque du
            # moteur pas encore passes/exécutés". ──
            "signal_accepted": len(accepted),
            "risk_passed": 0,            # complete par le moteur
            "order_authorized": 0,       # complete par le moteur
            "order_submitted": 0,        # complete par le moteur
            "shadow_decisions": len(accepted),
            "accepted": len(accepted),   # alias historique de signal_accepted
            "orders_submitted": 0,       # complete par le moteur
            "orders": 0,                 # alias, complete par le moteur
            "fills_confirmed": 0,        # complete par le moteur
            "rejections": rejections,
            "rejections_before_ranking": rejections_prerank,
        }
        report["valid"] = report["scanner_included"]
        if self.save_artifacts:
            from market_scanner import _save_json as _sj
            _sj("classification_report.json",
                classification_report(own_snapshots))
            top = sorted(self.last_traces,
                         key=lambda r: (r["ranker_score"] is not None,
                                        r["ranker_score"] or 0),
                         reverse=True)[:20]
            from market_scanner import _save_json
            _save_json("candidate_trace.json",
                       {"generated": report.get("scanned"), "top20": top,
                        "all_examined": len(self.last_traces)})
        return {"accepted": accepted, "report": report}

    @staticmethod
    def _book_from_snapshot(s: MarketSnapshot) -> Optional[dict]:
        if s.yes_bid is None or s.yes_ask is None:
            return None
        return {"yes_bid": s.yes_bid, "yes_ask": s.yes_ask,
                "no_bid": s.no_bid, "no_ask": s.no_ask,
                "spread": s.spread_yes}
