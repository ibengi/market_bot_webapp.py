"""
strategy_router.py — v1 (2026-07-11)
Routeur de strategies + evaluateur de signal avec portes edge/EV STRICTES.

PRINCIPES NON NEGOCIABLES :
- Un marche sans strategie compatible est rejete: no_compatible_strategy.
- Une strategie ne peut etre routee QUE vers ses categories declarees
  (jamais la strategie BTC vers un autre type de marche).
- Aucune probabilite n'est inventee : si la strategie ne fournit pas
  model_probability, rejet no_model_probability.
- edge <= 0 ou EV net < seuil => AUCUN trade. Le score de tradabilite du
  ranker n'est JAMAIS une preuve de rentabilite.

Interface strategie (duck typing) :
    strategy.categories : list[str]           categories servies
    strategy.name       : str
    strategy.evaluate(snapshot, fresh_market, book) -> dict | None
        dict = {"side": "yes"|"no", "model_prob": float 0..1 (prob que le
                cote choisi gagne), "confidence": int 0..10,
                "reason": str, "taille": "0.5%"|"1%"|"2%" (indicatif)}
        None = pas d'avis => rejet no_model_probability.
"""

import math
import os
import json
import logging
from dataclasses import dataclass, field, asdict
from typing import Optional

log = logging.getLogger("ROUTER")

REJECTION_REASONS = (
    "no_model_probability", "no_compatible_strategy", "insufficient_confidence",
    "no_positive_edge", "insufficient_net_edge", "negative_net_ev",
    "spread_too_wide", "no_executable_ask", "market_quality_too_low",
    "stale_book", "already_open", "risk_blocked",
    "insufficient_data_quality", "model_not_calibrated",
    "ambiguous_strategy_match",
)

# ── v3 (2026-07-19) : codes de resolution structures ────────────────────────
RESOLUTION_CODES = (
    "NO_REGISTERED_STRATEGIES", "NO_ENABLED_STRATEGIES",
    "UNSUPPORTED_MARKET_TYPE", "UNSUPPORTED_SERIES",
    "UNSUPPORTED_CATEGORY", "MISSING_REQUIRED_FEATURES",
    "STRATEGY_DISABLED", "MULTIPLE_COMPATIBLE_STRATEGIES",
    "STRATEGY_SELECTED",
)

from market_taxonomy import get_env_bool  # definition canonique unique


@dataclass
class SupportCheckResult:
    """Resultat detaille de supports_detailed() : plus jamais un simple
    False sans explication."""
    supported: bool
    reason_code: Optional[str] = None
    details: dict = field(default_factory=dict)


@dataclass
class StrategyResolutionResult:
    market_ticker: Optional[str]
    market_type: Optional[str]
    registered_strategy_names: list
    enabled_strategy_names: list
    compatible_strategy_names: list
    selected_strategy_name: Optional[str]
    rejection_code: Optional[str]
    rejection_details: dict = field(default_factory=dict)

@dataclass
class GateConfig:
    MIN_MODEL_CONFIDENCE: int = 6
    MIN_GROSS_EDGE: float = 0.05
    MIN_NET_EDGE: float = 0.03
    MIN_NET_EV: float = 0.02
    MAX_ACCEPTABLE_SPREAD: int = 4
    MIN_MARKET_SCORE: float = 50.0
    MIN_FILL_PROXY: float = 40.0
    SLIPPAGE_BUFFER_CENTS: int = 1
    UNCERTAINTY_BUFFER: float = 0.01     # marge d'incertitude modele (edge)
    FEE_RATE: float = 0.07               # fallback local documente (a verifier)
    REQUIRE_CALIBRATED: bool = False     # True en LIVE : modele calibre exige

@dataclass
class SignalDecision:
    ticker: str
    accepted: bool
    rejection_reason: Optional[str] = None
    side: Optional[str] = None
    entry_price_cents: Optional[int] = None
    market_probability: Optional[float] = None
    model_probability: Optional[float] = None
    gross_edge: Optional[float] = None
    expected_gross_value: Optional[float] = None
    estimated_fees: Optional[float] = None       # $ / contrat
    expected_slippage: Optional[float] = None    # $ / contrat
    net_edge: Optional[float] = None
    net_ev: Optional[float] = None
    confidence: int = 0
    strategy: Optional[str] = None
    taille: str = "0.5%"
    reason: str = ""
    model_output: Optional[dict] = None

def estimated_fee_per_contract(price_cents: int, fee_rate: float) -> float:
    """Fallback LOCAL documente: ceil(rate*P*(1-P)) au cent, par contrat.
    Utilise uniquement avant l'ordre; apres fill, les frais API priment."""
    p = price_cents / 100.0
    return math.ceil(fee_rate * p * (1 - p) * 100) / 100.0

class StrategyRouter:
    """Routeur STRICT. Chaque strategie DOIT exposer supports(snapshot).
    - 0 correspondance  -> (None, "no_compatible_strategy")
    - 1 correspondance  -> (strategie, None)
    - >1 correspondance -> (None, "ambiguous_strategy_match")
    Jamais de choix silencieux de la premiere strategie ; jamais de routage
    par categorie generale seule."""
    def __init__(self):
        self._strategies = []
        self._disabled = []            # noms refuses par flag enabled=False

    def register(self, strategy):
        if not callable(getattr(strategy, "supports", None)):
            log.warning(f"Strategie {getattr(strategy,'name',strategy)} sans "
                        f"supports(): REFUSEE par le routeur strict.")
            return
        name = getattr(strategy, "name", strategy.__class__.__name__)
        if not getattr(strategy, "enabled", True):
            self._disabled.append(name)
            log.warning(f"[STRATEGY_DISABLED] {name} desactivee par "
                        f"configuration -- non enregistree.")
            return
        if any(s is strategy for s in self._strategies):
            log.warning(f"Strategie {name} deja enregistree (meme objet) -- "
                        f"doublon ignore.")
            return
        if any(getattr(s, "name", s.__class__.__name__) == name
               for s in self._strategies):
            log.warning(f"Strategie nommee '{name}' deja presente -- "
                        f"second enregistrement du meme nom REFUSE.")
            return
        self._strategies.append(strategy)

    def strategies(self) -> list:
        return list(self._strategies)

    # ── v3 : validation et journal de demarrage obligatoires ────────────────
    def validate(self):
        """Leve une erreur EXPLICITE si aucune strategie active. Le programme
        ne doit pas continuer silencieusement avec un registre vide."""
        if not self._strategies:
            raise RuntimeError(
                "No active trading strategies registered"
                + (f" (desactivees: {self._disabled})" if self._disabled
                   else ""))
        return True

    def log_boot(self):
        """[STRATEGY_REGISTRY_BOOT] : etat complet du registre au demarrage."""
        entries = [{"name": getattr(s, "name", s.__class__.__name__),
                    "enabled": True,
                    "priority": getattr(s, "priority", 0),
                    "supported_market_types":
                        list(getattr(s, "supported_market_types", ()) or ()),
                    "supported_series":
                        list(getattr(s, "supported_series", ()) or ())}
                   for s in self._strategies]
        log.info("[STRATEGY_REGISTRY_BOOT] "
                 + json.dumps({"count": len(entries),
                               "disabled": self._disabled,
                               "strategies": entries}, ensure_ascii=False))
        return entries

    def resolve(self, snapshot):
        """(strategie|None, raison_rejet|None).
        v3 : si PLUSIEURS strategies correspondent, selection DETERMINISTE
        par priorite declaree (attribut `priority`, plus grand = prioritaire)
        UNIQUEMENT si un maximum STRICT existe ; egalite de priorite ->
        ambiguous_strategy_match (jamais de choix dependant de l'ordre
        d'import ou d'un dict)."""
        matches = [s for s in self._strategies if s.supports(snapshot)]
        if not matches:
            return None, "no_compatible_strategy"
        if len(matches) > 1:
            prios = [(getattr(s, "priority", 0), s) for s in matches]
            top = max(p for p, _ in prios)
            best = [s for p, s in prios if p == top]
            if len(best) == 1:
                names = [getattr(s, "name", s.__class__.__name__)
                         for s in matches]
                sel = getattr(best[0], "name", best[0].__class__.__name__)
                log.info(f"{snapshot.ticker}: {len(matches)} strategies "
                         f"compatibles {names} -- selection deterministe par "
                         f"priorite: {sel} (priority={top})")
                return best[0], None
            names = [getattr(s, "name", s.__class__.__name__) for s in matches]
            log.warning(f"{snapshot.ticker}: correspondance AMBIGUE "
                        f"({names}, priorites egales) -- rejet.")
            return None, "ambiguous_strategy_match"
        return matches[0], None

    # compat lecture seule (diagnostic)
    def supported_categories(self) -> list:
        cats = set()
        for s in self._strategies:
            cats.update(getattr(s, "categories", []))
        return sorted(cats)

    # ── v2 (2026-07-19) : le scanner derive son univers des strategies ──────
    def supported_series(self) -> list:
        """Series Kalshi declarees par les strategies ACTIVES enregistrees.
        Source unique pour ScanConfig.PRIORITY_SERIES : le scanner ne
        maintient AUCUNE liste independante susceptible de diverger."""
        out = set()
        for s in self._strategies:
            out.update(getattr(s, "supported_series", ()) or ())
        return sorted(out)

    def supported_market_types(self) -> list:
        out = set()
        for s in self._strategies:
            out.update(getattr(s, "supported_market_types", ()) or ())
        return sorted(out)

    def resolve_detailed(self, snapshot) -> "StrategyResolutionResult":
        """Diagnostic structure — meme logique que resolve() (verifie par
        test), sortie StrategyResolutionResult avec codes normalises."""
        strat, why = self.resolve(snapshot)
        registered = [getattr(s, "name", s.__class__.__name__)
                      for s in self._strategies]
        matches = [getattr(s, "name", s.__class__.__name__)
                   for s in self._strategies if s.supports(snapshot)]
        details = {"registered_series": self.supported_series(),
                   "registered_market_types": self.supported_market_types(),
                   "disabled_strategies": list(self._disabled)}
        if strat is not None:
            code = "STRATEGY_SELECTED"
        elif not self._strategies:
            code = ("NO_ENABLED_STRATEGIES" if self._disabled
                    else "NO_REGISTERED_STRATEGIES")
        elif why == "ambiguous_strategy_match":
            code = "MULTIPLE_COMPATIBLE_STRATEGIES"
        else:
            code = "UNSUPPORTED_MARKET_TYPE"
            per = {}
            for s in self._strategies:
                nm = getattr(s, "name", s.__class__.__name__)
                if callable(getattr(s, "supports_detailed", None)):
                    try:
                        r = s.supports_detailed(snapshot)
                        per[nm] = {"reason_code": r.reason_code,
                                   "details": r.details}
                    except Exception as e:
                        per[nm] = {"reason_code": "SUPPORT_CHECK_ERROR",
                                   "details": {"error": str(e)}}
            if per:
                details["per_strategy"] = per
                codes = {v["reason_code"] for v in per.values()}
                if codes == {"UNSUPPORTED_SERIES"}:
                    code = "UNSUPPORTED_SERIES"
        return StrategyResolutionResult(
            market_ticker=getattr(snapshot, "ticker", None),
            market_type=str(getattr(snapshot, "market_type", None)),
            registered_strategy_names=registered,
            enabled_strategy_names=list(registered),
            compatible_strategy_names=matches,
            selected_strategy_name=(getattr(strat, "name",
                                            strat.__class__.__name__)
                                    if strat is not None else None),
            rejection_code=None if strat is not None else code,
            rejection_details=details)

def evaluate_candidate(snapshot, fresh_market: dict, book: dict,
                       router: StrategyRouter,
                       gates: GateConfig) -> SignalDecision:
    """Toutes les portes, dans l'ordre, avec raison explicite.
    book = carnet FRAIS normalise {yes_bid,yes_ask,no_bid,no_ask,spread}."""
    tk = snapshot.ticker
    d = SignalDecision(ticker=tk, accepted=False)

    # 0) qualite de marche (le ranker mesure la TRADABILITE, pas le profit)
    q = getattr(snapshot, "quality", None)
    if q is not None:
        if q.total_score < gates.MIN_MARKET_SCORE:
            d.rejection_reason = "market_quality_too_low"; return d
        if q.fill_probability_score < gates.MIN_FILL_PROXY:
            d.rejection_reason = "market_quality_too_low"; return d

    # 1) resolution STRICTE par supports() (jamais par categorie seule)
    strat, why = router.resolve(snapshot)
    if strat is None:
        d.rejection_reason = why; return d
    d.strategy = getattr(strat, "name", strat.__class__.__name__)

    # 2) carnet frais exploitable ?
    if not book:
        d.rejection_reason = "stale_book"; return d
    spread = book.get("spread")
    if spread is None or spread > gates.MAX_ACCEPTABLE_SPREAD:
        d.rejection_reason = "spread_too_wide"; return d

    # 3) probabilite modele INDEPENDANTE
    out = strat.evaluate(snapshot, fresh_market, book)
    if isinstance(out, dict) and out.get("rejection_reason"):
        d.rejection_reason = out["rejection_reason"]        # ex: qualite data
        d.reason = str(out.get("reason", ""))[:160]
        return d
    if not out or out.get("model_prob") is None:
        d.rejection_reason = "no_model_probability"; return d
    side = out.get("side")
    if side not in ("yes", "no"):
        d.rejection_reason = "no_model_probability"; return d
    model_p = float(out["model_prob"])
    if not (0.0 < model_p < 1.0) or model_p != model_p:
        d.rejection_reason = "no_model_probability"; return d
    d.side, d.model_probability = side, model_p
    conf = out.get("confidence", 0)
    # confiance acceptee en 0..1 (modele) ou 0..10 (legacy)
    d.confidence = int(round(conf * 10)) if isinstance(conf, float) \
        and conf <= 1.0 else int(conf)
    d.taille = out.get("taille", "0.5%")
    d.reason = str(out.get("reason", ""))[:160]
    d.model_output = out.get("model_output")

    if gates.REQUIRE_CALIBRATED and not out.get("calibrated", False):
        d.rejection_reason = "model_not_calibrated"; return d
    if d.confidence < gates.MIN_MODEL_CONFIDENCE:
        d.rejection_reason = "insufficient_confidence"; return d

    # 4) ask executable du cote achete (jamais inventer un prix)
    ask = book.get("yes_ask") if side == "yes" else book.get("no_ask")
    if ask is None or not (1 <= int(ask) <= 99):
        d.rejection_reason = "no_executable_ask"; return d
    d.entry_price_cents = int(ask)

    # 5) edge & EV apres frais + slippage (formules par cote)
    d.market_probability = d.entry_price_cents / 100.0
    d.gross_edge = d.model_probability - d.market_probability
    if d.gross_edge <= 0:
        d.rejection_reason = "no_positive_edge"; return d
    if d.gross_edge < gates.MIN_GROSS_EDGE:
        d.rejection_reason = "insufficient_net_edge"; return d

    p = d.market_probability
    d.expected_gross_value = d.model_probability * (1 - p) \
        - (1 - d.model_probability) * p              # EV brute / contrat ($)
    d.estimated_fees = estimated_fee_per_contract(d.entry_price_cents,
                                                  gates.FEE_RATE)
    d.expected_slippage = gates.SLIPPAGE_BUFFER_CENTS / 100.0
    d.net_edge = d.gross_edge - d.estimated_fees - d.expected_slippage \
        - gates.UNCERTAINTY_BUFFER
    d.net_ev = d.expected_gross_value - d.estimated_fees - d.expected_slippage \
        - gates.UNCERTAINTY_BUFFER
    if d.net_edge < gates.MIN_NET_EDGE:
        d.rejection_reason = "insufficient_net_edge"; return d
    if d.net_ev < gates.MIN_NET_EV:
        d.rejection_reason = "negative_net_ev"; return d

    d.accepted = True
    return d

# ── Strategie crypto court terme (adaptateur, ne s'applique QU'A Crypto) ────

class CryptoShortTermStrategy:
    """Adapte l'analyse BTC existante SI et SEULEMENT SI elle fournit une
    probabilite modele independante (cle 'model_prob' ou 'prob_reelle'
    distincte de la prob marche). Sinon retourne None -> rejet honnete
    no_model_probability. AUCUNE probabilite n'est fabriquee ici."""
    name = "crypto_short_term_v1"
    categories = ["Crypto"]

    def __init__(self, decision_fn=None):
        # decision_fn(snapshot, market, book) -> dict de l'analyse existante
        self.decision_fn = decision_fn

    def evaluate(self, snapshot, fresh_market, book):
        if self.decision_fn is None:
            return None
        try:
            dec = self.decision_fn(snapshot, fresh_market, book) or {}
        except Exception as e:
            log.warning(f"{self.name}: decision_fn erreur: {e}")
            return None
        verdict = str(dec.get("verdict", "")).upper()
        side = "yes" if "YES" in verdict else "no" if "NO" in verdict else None
        model_p = dec.get("model_prob", dec.get("prob_reelle"))
        market_p = dec.get("market_prob")
        if side is None or model_p is None:
            return None
        # Une prob strictement egale a la prob marche n'est PAS un modele.
        if market_p is not None and abs(float(model_p) - float(market_p)) < 1e-9:
            return None
        return {"side": side, "model_prob": float(model_p),
                "confidence": int(dec.get("confidence", 0)),
                "taille": dec.get("taille", "0.5%"),
                "reason": dec.get("reason", "")}


# ── Strategie BTC 15 minutes basee sur le modele de probabilite ──────────────

class BtcModelStrategy:
    """Strategie BTC15M : contexte via btc_context, probabilite via
    btc_probability_model. NE S'APPLIQUE QU'AUX marches de la serie BTC 15
    minutes (supports()) : ETH, sports, politique, meteo etc. restent
    no_compatible_strategy. Si le contexte echoue -> no_model_probability ;
    si la qualite des donnees est insuffisante -> insufficient_data_quality.
    AUCUNE probabilite n'est inventee."""
    name = "btc15m_model_v1"
    categories = ["Crypto"]
    SERIES_PREFIX = "KXBTC15M"
    # Declarations consommees par le routeur puis le scanner (univers cible).
    # supports() reste le verrou final ; ces champs n'elargissent rien.
    supported_series = ("KXBTC15M",)
    supported_market_types = ("btc_above_strike_15m",)
    required_features = ("floor_strike|cap_strike|strike_price",
                         "minutes_remaining")
    priority = 100

    def __init__(self, context_provider=None, model_predict=None):
        # flag d'activation : lecture ROBUSTE (get_env_bool), jamais de
        # desactivation silencieuse — le routeur journalise tout refus.
        self.enabled = get_env_bool("BTC_STRATEGY_ENABLED", True)
        # injectables pour tests hors-ligne ; par defaut, les vrais modules
        if context_provider is None or model_predict is None:
            import btc_context as _ctx
            import btc_probability_model as _mdl
            context_provider = context_provider or _ctx.get_btc_context
            model_predict = model_predict or _mdl.predict_or_reason
        self.context_provider = context_provider
        self.model_predict = model_predict

    def supports(self, snapshot) -> bool:
        """Triple verrou impose : categorie Crypto ET market_type
        btc_above_strike_15m ET prefixe KXBTC15M. BTC horaire, ETH, daily
        et tout le reste sont refuses ici."""
        if getattr(snapshot, "category", None) != "Crypto":
            return False
        mt = getattr(snapshot, "market_type", None)
        if mt is not None and mt != "btc_above_strike_15m":
            return False
        for attr in ("series_ticker", "ticker"):
            v = str(getattr(snapshot, attr, None) or "").upper()
            if v.startswith(self.SERIES_PREFIX):
                return True
        return False

    def supports_detailed(self, snapshot) -> "SupportCheckResult":
        """Version expliquee de supports() : chaque False a un code."""
        base = {"market_type": str(getattr(snapshot, "market_type", None)),
                "series_ticker": getattr(snapshot, "series_ticker", None),
                "category": getattr(snapshot, "category", None),
                "allowed_series": list(self.supported_series),
                "allowed_market_types": list(self.supported_market_types)}
        if getattr(snapshot, "category", None) != "Crypto":
            return SupportCheckResult(False, "UNSUPPORTED_CATEGORY", base)
        mt = getattr(snapshot, "market_type", None)
        if mt is not None and mt != "btc_above_strike_15m":
            return SupportCheckResult(False, "UNSUPPORTED_MARKET_TYPE", base)
        for attr in ("series_ticker", "ticker"):
            v = str(getattr(snapshot, attr, None) or "").upper()
            if v.startswith(self.SERIES_PREFIX):
                return SupportCheckResult(True, None, base)
        return SupportCheckResult(False, "UNSUPPORTED_SERIES", base)

    @staticmethod
    def _strike(market: dict):
        for k in ("floor_strike", "cap_strike", "strike_price"):
            v = market.get(k)
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    pass
        return None

    def evaluate(self, snapshot, fresh_market, book):
        strike = self._strike(fresh_market or {})
        mins = getattr(snapshot, "minutes_remaining", None)
        if strike is None or mins is None:
            return {"rejection_reason": "no_model_probability",
                    "reason": "strike ou temps restant absent"}
        try:
            ctx = self.context_provider(strike=strike, minutes_remaining=mins)
        except Exception as e:                    # echec contexte = pas de prob
            return {"rejection_reason": "no_model_probability",
                    "reason": f"btc_context: {e}"}
        out, why = self.model_predict(ctx)
        if out is None:
            reason = ("insufficient_data_quality"
                      if why and "insufficient_data_quality" in why
                      else "no_model_probability")
            return {"rejection_reason": reason, "reason": why or ""}
        p_yes = out["probability_yes"]
        side = "yes" if p_yes >= 0.5 else "no"
        return {"side": side,
                "model_prob": p_yes if side == "yes"
                              else out["probability_no"],
                "confidence": out["confidence"],          # 0..1 -> mappee
                "calibrated": out.get("calibrated", False),
                "taille": "0.5%",
                "reason": f"{out['model_version']}: {out['reason'][:90]}",
                "model_output": out}


# ── Registre central : UNIQUEMENT les strategies reelles et testees ──────────
# Pas de fausse strategie Sports/Politics/Economics : ces marches restent
# no_compatible_strategy tant qu'un vrai modele dedie n'existe pas.

def available_strategies() -> list:
    return [BtcModelStrategy]


def build_default_router() -> "StrategyRouter":
    r = StrategyRouter()
    for cls in available_strategies():
        r.register(cls())
    return r
