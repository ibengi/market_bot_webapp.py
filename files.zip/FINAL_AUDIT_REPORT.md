# FINAL_AUDIT_REPORT — Kalshi Alpha Engine v11.0-pro
*Audit du 2026-07-11. Fichiers audités : kalshi_alpha_bot.py (v11.0-pro, 1152 lignes),
trade_resolver.py (v1 sur disque), kalshi_edge_measure.py, ml_model.py,
pattern_engine.py, debug_kalshi.py, btc_context - Copy.py (ancienne version),
bot_state.json, btc_trade_results.json (500 enregistrements), RAPPORT_AUDIT.md.*

**Fichiers NON fournis, donc NON audités** : `btc_context.py` (version courante — seule
une vieille copie sans `evaluate_btc_trade` a été fournie), `market_bot_webapp.py`,
`run.py`, `server.py`, `Procfile`, `requirements.txt`, `positions_state.json`,
`orders_state.json`, `risk_state.json`, `kalshi_trades.json`, `kalshi_alpha.log`.

**Limites de l'environnement d'audit, déclarées honnêtement** :
- Pas d'accès réseau → la validation API Demo réelle (§15) et la réconciliation broker
  réelle (§11) N'ONT PAS pu être exécutées. Ces catégories sont notées sur le code seul.
- `pytest` et `coverage` non installables (pas de réseau) → suite exécutée avec
  `unittest` (stdlib). **Le pourcentage de couverture ne peut pas être fourni** ;
  l'exigence "90 % de couverture" n'est PAS démontrée.

---

## 1. Résultat réel des tests

Suite : `test_audit_v11.py` (22 tests, hors-ligne, répertoires temporaires).

```
Ran 22 tests — 12 passed, 10 failed, 0 errors
```

**12 réussites (comportements vérifiés)** :
- Persistance atomique + récupération sur corruption (JsonStore) ✔
- Archivage des enregistrements legacy/dry-run hors statistiques ✔
- Mathématique de règlement : 4×YES@60c perdant → net **−2,47 $** et 4×YES@61c
  gagnant → net **+1,49 $**, valeurs identiques à celles observées dans les logs
  Railway du 10/07 — le chemin de règlement est cohérent ✔
- Pas de double règlement ✔
- Stop journalier déclenché par le PnL réalisé uniquement ✔
- Plafond dur 1 %/position, réduction ×0,5 si confiance ≤ 4, budget de risque ouvert ✔
- Normalisation du carnet (dérivation NO depuis YES, rejet carnet croisé) ✔

**10 échecs = 10 défauts de conformité prouvés (D1–D10)** :

| # | Défaut prouvé | Preuve |
|---|---|---|
| D1 | Les champs `fill_count_fp` / `remaining_count_fp` / `initial_count_fp` (format réellement renvoyé par l'API, fixture fournie par vous) **ne sont pas reconnus** : un ordre `status=resting` avec `fill_count_fp="2.00"` donne `filled=0` → fill réel manqué | test_D1 FAIL |
| D2 | Un ordre dont la réponse ne contient QUE `status="executed"` est considéré **entièrement rempli** (`filled=requested`) — exactement ce que le cahier des charges interdit | test_D2 FAIL, code l.554-555 |
| D3 | **RÈGLE ABSOLUE violée** : en `--demo` sans `KALSHI_DEMO_KEY_ID`, le client **se replie silencieusement sur les clés PROD** avec un simple warning, au lieu de `raise RuntimeError` | test_D3 FAIL, code l.210-217 |
| D4 | Aucune porte `MIN_REAL_EDGE` / `MIN_NET_EV` / `MIN_MODEL_CONFIDENCE` / `MAX_ACCEPTABLE_SPREAD` n'existe ; le bot **trade avec edge=0 et EV=0 par conception** (l.993-994), ce que le cahier des charges interdit | test_D4 FAIL |
| D5 | Aucune extraction des frais API (`taker_fees`, `maker_fees`…), pas de champ `fee_source` : formule locale uniquement | test_D5 FAIL |
| D6 | **Deux modèles de frais contradictoires coexistent** : v11 = 0,07×C×P×(1−P) ; trade_resolver v1 = 2,45 % des gains bruts. Même trade → PnL 1,53 $ vs 1,502 $. Toutes les stats de btc_trade_results.json reposent sur le mauvais barème | test_D6 FAIL |
| D7 | `pattern_engine.py` **ne s'importe pas** : `from typing import dict as Dict` → ImportError. Confirmé par votre bot_state.json ("Pattern: pattern_engine absent"). Le module n'a jamais fonctionné | test_D7 FAIL |
| D8 | `debug_kalshi.py` est syntaxiquement invalide (parenthèse orpheline) : ne compile pas | test_D8 FAIL |
| D9 | `kalshi_edge_measure.py` (CLI `resolve`) appelle `KalshiClient(demo=False)` : signature incompatible avec v11 (`env: str`) → TypeError, chemin CLI cassé | test_D9 FAIL |
| D10 | L'expression interdite `today.toordinal() - 7 and ...` est **toujours présente** (l.820). Elle fonctionne par accident (int non nul → renvoie la chaîne), mais le cahier des charges exige sa suppression | test_D10 FAIL |

## 2. Démonstration : le modèle ML est statistiquement invalide

Entraînement réel de `ml_model.py` sur vos 500 enregistrements :

```
Phase: 3 | n_trained: 500 | accuracy affichée: 0.996
Baseline "toujours perdu" : 498/500 = 99.6%
Prédictions >= 50% de proba de gain : 0/500
```

L'« accuracy 99,6 % » (98,8 % dans bot_state du 27/06) est **exactement la classe
majoritaire** : avec 2 gains sur 500, prédire « perdu » systématiquement donne 99,6 %.
Le modèle ne prédit JAMAIS une victoire, sa « confiance » sature à 1.0, et c'est cette
métrique dégénérée qui a servi de « confiance » aux décisions. Défauts structurels
supplémentaires, admis par le code lui-même (commentaires « inconnu apres coup ») :
- **Train/serve skew** : à l'entraînement, temps restant=0,5, volatilité=0,5,
  momentum=0 (constantes) ; en prédiction, valeurs réelles → les poids appris n'ont
  aucun sens en service.
- **Feature circulaire** : la « distance au strike » d'entraînement est reconstruite
  depuis le PRIX PAYÉ du contrat (= la probabilité du marché), pas depuis prix/strike.
- **Données d'entraînement corrompues** : 248 des 500 enregistrements (49,6 %) ont un
  schéma différent (sans `side`, `price`, `count` — écrits par un autre module) ;
  ml_model leur applique silencieusement side="yes", price=50.
- **Historique tronqué** : trade_resolver v1 coupe à 500 enregistrements (l.
  `if len(results) > 500`) → perte définitive des données au-delà.

Bilan chiffré du fichier : sur les 252 enregistrements valides, **2 gains (WR 0,79 %),
PnL enregistré −1 545,36 $** (26-27 juin, tailles de 11 à 1 000 contrats, moy. 323).
D'après votre RAPPORT_AUDIT, ces trades étaient des dry-run fantômes — le montant
n'est donc probablement pas une perte réelle, mais il mesure ce que la stratégie
« edge ML » aurait perdu, frais mal calculés inclus. bot_state.json montre par
ailleurs `mode: LIVE`, `daily_loss: 49.97` le 27/06 : le stop 50 $ a été touché.

## 3. Autres défauts identifiés à la lecture (non testables hors-ligne)

- **Capital figé** : `--capital` (défaut 500 $) sert au sizing ; `get_balance()` n'est
  appelé qu'en bannière. Pas de `BALANCE_REFRESH_SECONDS`, pas de refus de trader si
  solde indisponible (§3 du cahier des charges non satisfait).
- **Idempotence incomplète** : le `client_order_id` est bien réutilisé pendant les
  retries d'UN appel, mais il n'est **pas persisté avant l'envoi** et il n'existe pas
  de `find_order_by_client_order_id`. Crash entre le POST et la réponse → ordre
  potentiellement vivant chez Kalshi, inconnu localement (§10).
- **Fenêtre de crash au règlement** : `positions.pop()` + `flush()` AVANT
  `settle_trade()` ; un crash entre les deux laisse un trade « open » à jamais
  (position disparue, jamais réglée dans le journal).
- **Prix moyen de repli silencieux** : si `/portfolio/fills` échoue, le prix limite
  est enregistré comme prix moyen → slippage invisible dans les stats. De plus, des
  fills au format dollars-chaîne (`"0.1200"`) donneraient px=0, filtré → repli
  systématique.
- **`MAX_TRADES_CYCLE` inopérant** : `can_trade(cycle_trades=0)` est appelé en dur ;
  aucun `MAX_DAILY_TRADES`.
- **positions[ticker]** au lieu de positions[trade_id] (§8) — tenable uniquement
  grâce à ONE_TRADE_PER_MARKET.
- **Prod par défaut** : sans `--demo`, l'environnement est PROD (bloqué par
  KALSHI_ENV_CONFIRM, mais l'inversion est dangereuse) ; pas de flag `--live` (§16).
- **Aucune** base persistante (§9), **aucun** health_state.json (§17), **aucun**
  script de migration dédié (§18, l'archivage TradeLogger en couvre une partie),
  **aucun** module de calibration (§6), **aucun** mode `--validate-api` (§15),
  **aucun** rapport de réconciliation (§11).
- Stats manquantes (§13) : slippage, fill/cancel/rejection rate, latence, PnL par
  heure/côté/marché/version, retours sur capital/risque, séries de gains/pertes.

## 4. Notes finales — justification de chaque note < 10

| Catégorie | Note | Justification factuelle |
|---|---|---|
| Architecture | 6/10 | Classes à responsabilité unique, config centralisée, séparation claire — mais positions indexées par ticker (D-§8), pas de dataclasses/type hints complets, risk_state.json ne stocke que la date (inutile), deux résolveurs concurrents dans le repo, stratégie (btc_context.py) absente de la livraison. |
| API | 5/10 | Signature RSA, retry/backoff avec Retry-After, erreurs typées, [RAW:] pour vérifier les schémas — mais D3 (repli clés PROD), D5 (frais API ignorés), champ balance non vérifié, pas de find_order_by_client_order_id, endpoints jamais confrontés à l'API réelle. |
| Execution | 5/10 | TTL + annulation + polling + fills partiels corrects sur le papier — mais D2 (fill présumé sur statut), prix moyen de repli silencieux, `MAX_TRADES_CYCLE` inopérant, jamais exécuté contre un vrai ordre. |
| Fill tracking | 3/10 | D1 et D2 prouvés par tests : le format `_fp` — celui que VOTRE fixture montre — n'est pas lu, et le statut seul suffit à déclarer un fill. Pas de `normalize_order_response`, pas de champs is_terminal/is_partial. C'est le cœur du « zéro trade fantôme » et il n'est pas conforme. |
| Risk management | 6/10 | Le stop jour sur PnL réalisé recalculé depuis le journal est correct et testé (12 tests OK) ; plafond 1 % et budget 5 % testés — mais capital figé à 500 $ (pas le solde réel), pas de MAX_DAILY_TRADES ni MAX_MARKET_EXPOSURE, throttle drawdown non testé en conditions réelles. |
| Data persistence | 4/10 | JsonStore atomique + checksum + backups, testé y compris récupération sur corruption — mais aucune base de données (§9 entier non fait), aucun contrôle de persistance au démarrage sur Railway (fichiers toujours éphémères sans volume), resolver v1 écrit non-atomiquement et tronque à 500. |
| Recovery | 5/10 | Réconciliation des ordres orphelins au démarrage présente et sensée — mais fenêtre de crash POST→réponse (ordre inconnu localement), fenêtre pop/settle (trade zombie), pas de reconciliation_report.json, jamais testée contre le broker réel. |
| Statistics | 5/10 | Win rate/PF/expectancy/Kelly/MaxDD/courbe corrects, Sharpe honnêtement non annualisé — mais D6 (deux barèmes de frais → historiques incohérents), D10 (expression interdite toujours là), la majorité des métriques §13 absentes. |
| Testing | 1/10 | **Zéro test livré avec le moteur.** La suite de 22 tests jointe a été écrite pendant cet audit ; pytest/coverage non disponibles ici → couverture non mesurable, objectif 90 % non démontré. La note reflète l'état livré, pas cet audit. |
| Demo safety | 3/10 | Le mode demo envoie de vrais ordres (pas de dry-run résiduel : conforme) — mais D3 viole la règle qualifiée d'ABSOLUE : repli silencieux sur les clés PROD si les clés demo manquent. Tant que ce point n'est pas corrigé, le mode demo n'est pas sûr. |
| Production safety | 5/10 | KALSHI_ENV_CONFIRM=LIVE requis et vérifié à froid — mais la prod est l'environnement PAR DÉFAUT (absence de --demo), pas de flag --live : une seule barrière au lieu des deux exigées, et une ergonomie qui invite à l'erreur. |
| Strategy calibration | 1/10 | Le bot trade avec edge=0/EV=0 par conception (interdit, D4) ; aucun module de calibration (§6) ; le ML est démontré dégénéré (accuracy=classe majoritaire, 0 prédiction gagnante, train/serve skew, feature circulaire, données 49,6 % corrompues, historique tronqué) ; pattern_engine ne s'importe même pas (D7). Les données réelles : WR 0,79 %, −1 545 $ enregistrés. Rien, dans l'état, ne mesure ni ne produit un edge. |

**Aucune note de 10/10 n'est attribuable** : aucune catégorie n'a pu être validée de
bout en bout contre l'API Demo réelle, condition que vous avez vous-même fixée.

## 5. Ce qu'il faut corriger, dans l'ordre, avant tout essai sérieux en Demo

1. **D3** — clés demo obligatoires : `raise RuntimeError` si absentes (10 lignes).
2. **D1/D2** — `normalize_order_response()` avec support `_fp`, jamais de fill déduit
   du seul statut ; confirmer via `/portfolio/fills`.
3. **D4** — portes MIN_REAL_EDGE / MIN_NET_EV / MIN_MODEL_CONFIDENCE /
   MAX_ACCEPTABLE_SPREAD, et interdiction de trader si model_prob == market_prob.
   (Cela impliquera que le bot ne trade plus tant qu'un vrai modèle n'existe pas —
   c'est le but : mesurer d'abord avec kalshi_edge_measure, trader ensuite.)
4. **D6** — un seul FeeModel partagé ; purger/re-calculer btc_trade_results.json,
   supprimer la troncature à 500 ; un seul résolveur (celui du moteur).
5. **D7/D8/D9** — corriger l'import typing, supprimer debug_kalshi.py, aligner la
   signature client dans kalshi_edge_measure.
6. Capital réel (get_balance + refresh + refus de trader sans solde), persistance
   du client_order_id avant envoi, volume Railway (DATA_DIR) vérifié au démarrage.
7. Geler ml_model/pattern_engine tant que la chaîne de données n'est pas saine :
   les réactiver sans corriger les données reproduirait le 27 juin.

## 6. Critères avant passage en Production (inchangés, non négociables)

- 10 premiers ordres Demo : vérifier [RAW:create_order]/[RAW:fills], transmettre pour
  validation des noms de champs ; aucun écart fill local vs broker.
- ≥ 100-300 trades Demo résolus avec kalshi_edge_measure : borne basse de l'IC95 du
  taux de réussite > prix moyen payé + frais. En dessous, l'espérance est négative.
- Couverture de tests mesurée (pytest + coverage sur machine avec réseau) ≥ 90 % sur
  OrderManager, PositionManager, RiskManager, FeeModel, TradeLogger.
- Réconciliation broker au démarrage validée sur un crash provoqué volontairement.
