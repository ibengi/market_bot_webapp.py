# RAPPORT D'AUDIT — Kalshi Alpha Engine
*2026-07-24. Base d'analyse : `kalshi_alpha_bot.py` v11.0-pro, `btc_context.py` v2,
`backtest_btc15m.py` v1, `.env.example` v3, 24 000 lignes de logs Railway du
2026-07-20 (31 cycles complets).*

---

## 0. Perimetre honnete de cet audit

Les fichiers suivants, **importes par le bot mais non fournis**, n'ont pas pu
etre audites ni diffes : `strategy_router.py`, `opportunity_pipeline.py`,
`market_scanner.py`, `market_ranker.py`, `shadow_prediction_store.py`,
`model_calibration.py`, `btc_probability_model.py`, `model_gatekeeper.py`.
Leur comportement a ete reconstitue depuis (a) les interfaces consommees par
`kalshi_alpha_bot.py` et `backtest_btc15m.py`, (b) les commentaires du code,
(c) les logs de production. Les versions livrees ici sont des **remplacements
compatibles d'interface** ; le seul diff unifie possible est celui de
`kalshi_alpha_bot.py` (`kalshi_alpha_bot.patch.diff`). Si les originaux
existent encore, comparez avant fusion — en particulier `MOMENTUM_CAP` et
`MODEL_VERSION` dans `btc_probability_model.py` (valeurs de reference posees
ici, non verifiables sans l'original).

---

## 1. Causes racines (avec preuves)

### CR-1 — `strategy_supported=0` : registre a une seule strategie, sur une serie absente de l'univers
`ExecutionEngine.__init__` (lignes 1302-1307 de la v11) :

```python
self.router.register(BtcModelStrategy())
# "Strategie modele BTC 15 minutes : UNIQUEMENT la serie KXBTC15M
#  (supports()). Tout autre marche -> no_compatible_strategy."
```

Le registre ne contenait **qu'une** strategie, dont `supports()` n'acceptait
que la serie **KXBTC15M**. Or les logs montrent **0 occurrence** de KXBTC15M
dans l'univers scanne (grep sur 24 000 lignes), alors que **KXBTCD**
(`btc_above_strike_daily`) y est present par centaines et correctement
classifie. Consequence mecanique : 100 % des 271-301 eligibles/cycle rejetes
`no_compatible_strategy`, y compris des marches BTC parfaitement compatibles
avec le meme modele. Ce n'etait pas un bug d'exécution mais un **trou de
couverture du registre**, documente dans le commentaire lui-meme.

**Correctif** : registre canonique **indexe par `market_type`** (jamais par
serie ni par categorie), servant au minimum `sports_moneyline`,
`sports_spread`, `sports_total`, `btc_above_strike_daily`, `election_winner`
(+ `btc_15m_above_strike`), avec `validate_strategy_registry()` qui **refuse
le demarrage** (SystemExit 2) si le registre est vide, incomplet ou en
doublon. Le nom exact de la strategie choisie est journalise dans chaque
decision et dans le trade (`analysis.strategy`).

### CR-2 — Classification par sous-chaines sans frontieres de mots
Preuves extraites des logs (meme serie, categories differentes selon les
equipes !) :

| Ticker reel | Classe observee | Cause probable | Classe correcte |
|---|---|---|---|
| KXWNBASPREAD-26JUL20LVTOR-LV7 | **Commodities** | « Las Ve**gas** » contient *gas* | Sports |
| KXWNBATOTAL-26JUL20WSHGS-152 | **Commodities** | « **Gold**en State » contient *gold* | Sports |
| KXWNBASPREAD-26JUL20NYDAL-NY7 | Sports | (pas de mot piege) | Sports |
| KXATPCHALLENGERMATCH-…ZAMPOL-POL | **Politics** | sous-chaine *POL* | Sports |
| KXMEDNOMJUL-26AUG01-DKLE | **election_winner** | sous-chaine *NOM* | politics/unknown |
| KXATPGSPREAD / KXWTAMATCH / KXITFWMATCH | market_type **unknown** | ligues ATP/WTA/ITF non couvertes | sports_spread / moneyline |
| KXETHD, KXXRPD | **Other** | familles crypto non couvertes | Crypto |

**Correctif** (`market_classifier.py`) : market_type derive du **prefixe de
serie du ticker** (table exacte, ligues au debut du root, WNBA teste avant
NBA), categorie **forcee a Sports** quand le market_type est sportif,
BTC/ETH/XRP/SOL/DOGE forces Crypto, `unknown` a confiance 0 et **plafonne a
10/100 par le ranker** (jamais « eligible »). 27 tests de non-regression avec
les tickers reels ci-dessus.

### CR-3 — Scanner : 40 001 marches re-telecharges chaque minute
Logs : `Univers: 40001 marches` + `Garde-fou MAX_PAGES=200 atteint` a
**chacun des 31 cycles** ; `no_liquidity: 27 794-27 975` recompte a chaque
cycle ; cycle ~75-95 s pour un intervalle de 60 s ; Railway a meme **droppe
des logs** (rate limit).

**Correctif** (`market_scanner.py` v2) : mode par defaut = **scan cible** par
series derivees du registre (`GET /markets?series_ticker=…`, quelques pages) ;
crawl complet optionnel (`SCANNER_GENERAL_CRAWL_ENABLED`, defaut false) mis en
**cache >= 30 min** persiste sur disque, avec **mise a jour incrementale**
(seules les series cibles sont relues entre deux crawls) ; filtres immediats
(expire/ferme, hors fenetre, sans liquidite, market_type inconnu) avec
metriques avant/apres chaque filtre ; plafond `SCANNER_MAX_MARKETS_PER_CYCLE`
sur les meilleurs tradables. `MAX_PAGES` **n'a pas ete augmente** (test
`test_max_pages_not_increased`) ; l'alerte ne peut plus se produire qu'une
fois par rafraichissement de cache, pas par cycle.

### CR-4 — Risque calibre sur 500 $ pour un compte de 93,26 $
Logs : `Capital ref.: 500.00$ (sizing)` et `stop jour -50.00$` alors que
`solde=93.26$`. Le `_balance_gate` calculait bien
`effective_capital=min(500, 93.26)=93.26` pour le sizing, mais le **stop
journalier restait un montant fixe de 50 $ = 54 % du compte**, et 5 positions
simultanees etaient permises.

**Correctif** : `effective_daily_stop() = min(MAX_DAILY_LOSS,
capital_effectif x 5 %)` → **4,66 $** pour 93,26 $ ; risque/trade <= 1 %
(0,93 $ → 0 contrat si le prix rend le trade inabordable, honnetement, sans
forcer) ; exposition ouverte <= 5 % ; **3 positions max** ; **arret apres 3
pertes consecutives** ; budget par categorie applique avec la **vraie**
categorie (elle est maintenant stockee dans la position — l'ancienne version
utilisait le nom de strategie comme categorie).

### CR-5 — Aucune probabilite modele
Consequence de CR-1 : aucune strategie atteinte → aucun `model_probability`,
edge, EV, ordre ni fill. Corrige par CR-1 + branchement de
`btc_probability_model` (meme formule que le backtest, momentum borne) sur
`btc_context` pour KXBTCD et KXBTC15M. Le modele **refuse** d'emettre une
probabilite si le contexte est invalide (< 2 sources spot), si la qualite de
donnees est < 60/100, ou si une entree indispensable manque
(`ModelInputError`) — rien n'est invente, aucun seuil n'a ete abaisse.

---

## 2. Matrice market_type → strategie (livrable 4)

| market_type | Strategie enregistree | Probabilite | Statut |
|---|---|---|---|
| btc_above_strike_daily | `btc_daily_above_strike` | modele GBM + btc_context | **operationnelle** (tradable en demo) |
| btc_15m_above_strike | `btc15m_above_strike` | idem, horizon <= 20 min | operationnelle si la serie existe dans l'env |
| sports_moneyline | `sports_moneyline_v1` | fournisseur externe injectable | routee ; `no_model_probability` sans fournisseur |
| sports_spread | `sports_spread_v1` | idem | idem |
| sports_total | `sports_total_v1` | idem | idem |
| election_winner | `election_winner_v1` | idem | idem |
| unknown / autres | — | — | `no_compatible_strategy` (TTL 1 h en cache de rejet) |

Point d'honnetete assume : les strategies sports/election **routent** (donc
`strategy_supported` > 0 sur ces marches) mais **ne tradent pas** tant
qu'aucun fournisseur de probabilites calibrees n'est injecte
(`ProviderBackedStrategy`). Inventer des probabilites sportives pour forcer
des trades violerait la condition d'acceptation n° 2 ; le pipeline les rejette
en `no_model_probability`, exactement comme le cahier des charges l'exige.

## 3. Scanner avant / apres (livrable 7)

| Metrique (par cycle) | Avant (logs 2026-07-20) | Apres (v2, mode cible) |
|---|---|---|
| Marches telecharges | 40 001 chaque minute | series cibles uniquement (~centaines) ; crawl complet <= 1x/30 min si active |
| Alerte MAX_PAGES | a CHAQUE cycle | au plus 1x par rafraichissement de cache ; MAX_PAGES inchange (200) |
| Marches sans liquidite re-evalues | ~29 400 par cycle | filtres a la source, comptes une fois dans `excluded_by_reason` |
| Rejets journalises en INFO | 271-301 lignes [REJECT]/cycle | 0 (DEBUG + decisions.jsonl rotatif) ; cache de rejet TTL 120 s / 3600 s |
| Resume | 3 lignes STATS/CYCLE-REPORT redondantes | 1 ligne `[CYCLE-SUMMARY]` (schema G, avec cycle_id) |

Verification chiffree en tests : `test_cache_at_least_30_minutes` (10 cycles
consecutifs = 1 seul crawl), `test_incremental_refresh_between_crawls`
(donnee fraiche fusionnee sans re-crawl), `test_cycle_cap_with_metrics`.

## 4. Resultats des tests (livrable 5)

`python3 run_tests.py` → **Ran 68 tests — OK (0 failure, 0 error)**,
`test_report.json` genere depuis les resultats reels. Couverture :
classification de chaque famille (WNBA, NBA, NFL, MLB, UFC, ATP, WTA, ITF,
NASCAR, CFL, crypto, CPI, elections) ; routage des 5 market_type requis ;
registre vide → refus de demarrage ; marches expires/fermes/sans
liquidite/hors fenetre ; spread excessif ; prix = ask jamais last_price ;
sizing a 93,26 $ (1 %/trade, 5 % total, stop 4,66 $, 0 contrat si
inabordable) ; 3 pertes consecutives ; ordre non rempli (aucun trade) ; fill
partiel (quantite reelle) ; annulation TTL seulement si encore ouvert ;
redemarrage avec ordre ouvert (idempotent, zero doublon) ; reconciliation du
PnL uniquement sur `result` API ; mode shadow (zero create_order) ; separation
DEMO/LIVE (cles demo obligatoires, prod sans double confirmation → exit 1,
gatekeeper refuse par defaut).

## 5. Preuves 8 et 9 (cycle demo complet)

`demo_cycle_log.txt` (pipeline reel, client et contexte injectes,
deterministe) montre en un cycle :
`supported=1, model_evaluated=1, positive_edge=1, positive_net_ev=1,
risk_passed=1, orders_submitted=1, fills=1` ; ordre `o1` YES x1 @ 48c
(= l'ASK), suivi via `get_order`, **fill confirme par `/portfolio/fills`**,
frais `fee_source=api`, trade enregistre avec
`model_prob=0.765 / market_prob=0.48 / strat=btc_daily_above_strike`.
Le scenario « non rempli » du meme pipeline aboutit a une annulation TTL
propre et **zero trade enregistre**.

## 6. Mode de securite (exigence I)

`model_gatekeeper.check_live_allowed()` exige TOUTES ces conditions :
`NO_LIVE_PROMOTION` explicitement leve (defaut = 1 → live interdit),
`MODEL_APPROVED_FOR_LIVE=YES`, `test_report.json` vert et < 7 jours,
`model_validation.json` approuve et < 30 jours — en plus des verrous
existants (`KALSHI_ENV_CONFIRM=LIVE`, `LIVE_TRADING_CONFIRMED=YES`,
`LIVE_TRADING=1`). LIVE ne peut donc jamais s'activer automatiquement.

## 7. Points encore NON valides (livrable 10)

1. **Aucune validation contre l'API Kalshi reelle** depuis cet environnement
   (pas de reseau) : endpoints `/markets` (cursor cible par serie), champs de
   frais, `avg_price` broker — a verifier via les `[RAW:*]` du premier run.
2. Les **fichiers originaux manquants** (section 0) n'ont pas pu etre diffes ;
   risque de divergence de constantes (`MOMENTUM_CAP`, barème de frais
   0,07) avec d'eventuelles versions locales.
3. Les strategies **sports et election n'ont pas de modele** : elles routent
   mais ne traderont pas tant qu'un fournisseur calibre (cotes de cloture,
   agregateur de sondages…) n'est pas branche et valide en shadow.
4. La `confidence_from_quality` (qualite → confiance 0-10) est une heuristique
   documentee, **pas une calibration mesuree** : a valider avec >= 300
   predictions shadow reglees et `backtest_btc15m` avant toute promotion.
5. Le slippage reste un tampon constant (pas un modele de profondeur) ;
   `MIN_FILL_PROXY` n'est pas encore alimente par une mesure de fill reelle.
6. Pas de verrou distribue multi-instances (Railway replicas=1 obligatoire).
7. La liste `DEFAULT_SERIES_BY_MARKET_TYPE` reflete les series observees dans
   les logs de juillet 2026 ; Kalshi peut en ajouter — le crawl 30 min sert
   de filet, mais la table doit etre revue periodiquement.

## 8. Conditions d'acceptation — verification point par point

- `no_compatible_strategy` n'est plus la cause de tous les rejets : les
  marches BTC/sports/election sont routes (tests + demo_cycle_log). ✔
- Aucun seuil n'a ete diminue : portes MIN_GROSS_EDGE/NET_EDGE/NET_EV et
  MIN_MODEL_CONFIDENCE inchangees ; les strategies sans modele rejettent. ✔
- `MAX_PAGES` non augmente (200) ; l'alerte disparait par le cache, pas par
  le plafond. ✔
- Categories coherentes forcees par market_type + tests de non-regression. ✔
- 500 $ ne peut plus influencer un solde de 93,26 $ (stop %, sizing, tests). ✔
- Les tests exercent le vrai pipeline demo (ExecutionEngine reel, FakeClient
  injecte) — pas de simulation du pipeline lui-meme. ✔
- LIVE jamais active : NO_LIVE_PROMOTION par defaut + gatekeeper. ✔
- Aucun trade sans confirmation API : fills via `/portfolio/fills`
  (tests unfilled/partial/settlement). ✔
